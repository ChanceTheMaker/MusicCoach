/* SPDX-License-Identifier: GPL-3.0-only
 * MusicCoach lesson engine. Original code, 2026 Chance Roth / MusicCoach.
 * No hardware, audio, allocation or Felucca dependencies. Time is in ms.
 */
#pragma once
#include <stdint.h>
enum { MC_HOME, MC_PLAY, MC_RESULT };
enum { MC_LEARN, MC_RHYTHM, MC_DEMO };
enum { MC_COACH, MC_JAM, MC_PSYCHEDELIC };
enum { MC_START, MC_BACK, MC_LESSON, MC_MODE, MC_TEMPO, MC_RESTART, MC_THEME, MC_COUNTIN, MC_SOUND, MC_SHUTTLE, MC_VOLUME, MC_KEYBOARD, MC_VIEW, MC_FXPAGE, MC_DRUMBANK, MC_K5, MC_K6, MC_K7, MC_K8, MC_SETTINGS, MC_SURFACE, MC_LIGHTSHOW, MC_BRIGHTNESS, MC_TRAIN_LANE, MC_DRUMVIEW, MC_SCENE, MC_BROWSE, MC_FXSELECT, MC_SMKBUTTON };
static const char *const mc_scenes[]={"AUTO TOUR","NEON HORIZON","ORBITAL RIBBONS","THOUGHT VORTEX","PRISM BLOOM","STRING THEORY","STAR CHOIR"};
#define MC_SCENES 7
typedef struct { uint32_t at; uint8_t note,velocity,drum; } mc_visual_hit;
static const char *const mc_sounds[]={"PIANO","E-PIANO","ORGAN","SYNTH","FLUTE","SAX"};
#define MC_SOUNDS (sizeof(mc_sounds)/sizeof(mc_sounds[0]))
static const char *const mc_views[]={"COACH","JAM","PSYCHEDELIC"};
static const char *const mc_fxpages[]={"FX","LFO","ARP","SCALE","CHORD","NOTE REPEAT","SEQUENCER"};
static const char *const mc_pad_names[]={"KICK","SNARE","CLAP","CL HAT","OP HAT","LOW TOM","MID TOM","HI TOM","RIM","COWBELL","CRASH","RIDE","SHAKER","CLAVE","LOW KICK","SNAP"};
static const char *const mc_themes[]={"COACH RED","FM-1 MINT","PRO NEON","ELITE GOLD","VAPOR","ARCTIC","EMBER","OCEAN","ORCHID","ACID","ROSE","MONO"};
typedef struct { uint8_t note[3], finger[3], count, beats; } mc_step;
typedef struct { const char *title,*hint; const mc_step *steps; uint8_t count,low,kind; uint16_t target[4]; } mc_lesson;
#include "musiccoach_library.h"
#define MC_LESSONS (sizeof(mc_lessons)/sizeof(mc_lessons[0]))
typedef struct {
 uint32_t last_ms, remainder, flash_until, score;
 int32_t beat;
 uint16_t hits,misses,wrong,combo,best_combo,bpm;
 uint8_t page,mode,lesson,index,running,countin,theme,feedback,initialized;
 uint8_t sound,volume,keyboard_smk,seeked,seek_serial;
 uint8_t app_mode,fxpage,drum_bank,seq_on,seq_pattern,seq_restart,jam_step,energy;
 uint8_t settings,surface,lightshow,brightness,boot_muted;
 int16_t fx_delta[7][4],seq_seek;
 uint32_t boot_ms,controls_until,pad_flash[16];
 uint16_t pads_held,train_pattern[4];
 uint8_t train_lane,drumview;
 uint8_t scene,visual_next;
 mc_visual_hit visual_hits[12];
 uint8_t held[128],best[MC_LESSONS];
} mc_state;
static mc_state mc;
/* Called on the audio consumer for actual synth attacks, including MIDI,
 * arpeggios and sequencer playback. Note-offs never create a burst. */
static void mc_visual_attack(unsigned note,unsigned velocity,unsigned drum,uint32_t now){
 if(!velocity)return;
 mc.visual_hits[mc.visual_next]=(mc_visual_hit){now,(uint8_t)note,(uint8_t)(velocity>127?127:velocity),(uint8_t)!!drum};
 mc.visual_next=(mc.visual_next+1)%12;
}
static unsigned mc_visual_level(unsigned drum,uint32_t now){
 unsigned peak=0;
 for(unsigned i=0;i<12;i++){const mc_visual_hit *h=&mc.visual_hits[i];unsigned age=now-h->at;
  if(h->velocity&&h->drum==drum&&age<700){unsigned v=h->velocity*(700-age)/350;if(v>peak)peak=v;}
 }return peak;
}
static unsigned mc_browse_index(void){return mc.app_mode==MC_PSYCHEDELIC?2+mc.scene:mc.app_mode;}
static const mc_lesson *mc_current(void){return &mc_lessons[mc.lesson];}
static int32_t mc_at(unsigned index){int32_t beat=1000;const mc_lesson *l=mc_current();for(unsigned i=0;i<index&&i<l->count;i++)beat+=250*l->steps[i].beats;return beat;}
static unsigned mc_accuracy(void){unsigned n=mc.hits+mc.misses+mc.wrong;return n?100u*mc.hits/n:0;}
static unsigned mc_stars(void){unsigned a=mc_accuracy();return mc.mode==MC_DEMO||mc.seeked?0:a>=95?3:a>=75?2:mc.hits?1:0;}
static void mc_reset(void){mc.beat=0;mc.index=mc.hits=mc.misses=mc.wrong=mc.combo=mc.best_combo=mc.score=mc.remainder=0;mc.feedback=mc.seeked=0;mc.running=0;}
static void mc_init(uint32_t now){mc=(mc_state){0};mc.bpm=88;mc.countin=1;mc.volume=64;mc.lightshow=1;mc.drumview=1;mc.brightness=4;mc.last_ms=mc.boot_ms=now;mc.initialized=1;
#if MUSICCOACH_SMK
 mc.keyboard_smk=1;
#endif
}
/* UI commands are queued, then applied by the audio/timer consumer. */
static volatile uint8_t mc_qwrite,mc_qread;
static struct { uint8_t kind; int16_t value; } mc_queue[16];
static void mc_command(unsigned kind,int value){uint8_t w=mc_qwrite;if((uint8_t)(w-mc_qread)>=16)return;mc_queue[w&15].kind=kind;mc_queue[w&15].value=value;__asm__ volatile("":::"memory");mc_qwrite=w+1;}
static void mc_apply(unsigned kind,int value){
 /* Resolve physical shortcuts on this consumer, after earlier queued actions.
  * Never compute page offsets or menu-dependent actions from stale UI state. */
 if(kind==MC_SMKBUTTON){
  if(value<0||value>=18)return;
  unsigned b=(unsigned)value;mc.boot_muted=1;
  if(mc.settings){if(b==11||b==12||b==10)mc_apply(MC_BACK,0);else if(b==15)mc_apply(MC_DRUMVIEW,0);return;}
  if(b==16)mc_apply(MC_START,0);else if(b==17)mc_apply(MC_RESTART,0);else if(b==12)mc_apply(MC_BACK,0);
  else if(b==2||b==3)mc_apply(!mc.app_mode&&mc_current()->kind==2?MC_TRAIN_LANE:MC_LESSON,b==2?-1:1);
  else if(b==4||b==5)mc_apply(MC_TEMPO,b==4?-1:1);
  else if(b==10)mc_apply(MC_VIEW,1);else if(b==11)mc_apply(MC_SETTINGS,0);
  else if(b==13)mc_apply(MC_COUNTIN,0);else if(b==14)mc_apply(MC_FXSELECT,0);else if(b==0)mc_apply(MC_FXPAGE,1);
  else if(b==1)mc_apply(MC_DRUMBANK,0);
  else if(b>=6&&b<=9)mc_apply(MC_FXSELECT,(unsigned[]){2,5,3,4}[b-6]);
  else if(b==15)mc_apply(!mc.app_mode?MC_MODE:MC_FXSELECT,!mc.app_mode?1:6);
  return;
 }
 if(kind==MC_START||kind==MC_RESTART||kind==MC_VIEW||kind==MC_LESSON||kind==MC_SCENE||kind==MC_BROWSE)mc.boot_muted=1;
 if(kind==MC_SCENE)mc.scene=(mc.scene+MC_SCENES+value%MC_SCENES)%MC_SCENES;
 if(kind==MC_BROWSE){int n=((int)mc_browse_index()+9+value%9)%9;unsigned next=n<2?n:MC_PSYCHEDELIC;
  if(!next||!mc.app_mode)mc.running=mc.seq_on=0;
  mc.app_mode=next;if(n>=2)mc.scene=n-2;
 }
 if(kind==MC_DRUMVIEW)mc.drumview=!mc.drumview;
 if(kind==MC_TRAIN_LANE)mc.train_lane=(mc.train_lane+4+value%4)%4;
 if(kind==MC_SETTINGS){mc.settings=!mc.settings;mc.running=mc.seq_on=0;}
 if(kind==MC_BACK&&mc.settings){mc.settings=0;return;}
 if(kind==MC_SURFACE)mc.surface=(mc.surface+3+value%3)%3;
 if(kind==MC_LIGHTSHOW)mc.lightshow=!mc.lightshow;
 if(kind==MC_BRIGHTNESS){int n=mc.brightness+value;mc.brightness=n<0?0:n>8?8:n;}
 if(kind==MC_VIEW){unsigned next=(mc.app_mode+3+value%3)%3;if(!next||!mc.app_mode)mc.running=mc.seq_on=0;mc.app_mode=next;}
 if(kind==MC_FXPAGE){mc.fxpage=(mc.fxpage+7+value%7)%7;mc.controls_until=mc.last_ms+3000;}
 if(kind==MC_FXSELECT&&value>=0&&value<7){mc.fxpage=value;mc.controls_until=mc.last_ms+3000;mc.boot_muted=1;}
 if(kind==MC_DRUMBANK)mc.drum_bank=!mc.drum_bank;
 if(kind>=MC_K5&&kind<=MC_K8){int v=mc.fx_delta[mc.fxpage][kind-MC_K5]+value;mc.fx_delta[mc.fxpage][kind-MC_K5]=v< -127?-127:v>127?127:v;mc.controls_until=mc.last_ms+3000;}
 if((mc.app_mode||mc_current()->kind==2)&&kind==MC_START){mc.page=MC_PLAY;mc.seq_on=!mc.seq_on;return;}
 if((mc.app_mode||mc_current()->kind==2)&&kind==MC_RESTART){mc_reset();for(unsigned i=0;i<4;i++)mc.train_pattern[i]=0;mc.page=MC_PLAY;mc.seq_on=1;mc.seq_restart++;return;}
 if((mc.app_mode||mc_current()->kind==2)&&kind==MC_SHUTTLE){int v=mc.seq_seek+value;mc.seq_seek=v< -64?-64:v>64?64:v;return;}
 if(kind==MC_START){if(mc.page!=MC_PLAY){mc_reset();mc.page=MC_PLAY;}mc.running=!mc.running;if(mc.running&&mc.beat==0&&mc.countin)mc.beat=-4000;}
 if(kind==MC_BACK){mc.running=mc.seq_on=0;mc.page=MC_HOME;mc.app_mode=MC_COACH;}
 if(kind==MC_LESSON){int n=(int)mc.lesson+value;unsigned count=mc.keyboard_smk?MC_LESSONS:47;while(n<0)n+=count;mc.lesson=n%count;mc.seq_on=0;mc.train_lane=0;for(unsigned i=0;i<4;i++)mc.train_pattern[i]=0;mc_reset();mc.page=MC_HOME;}
 if(kind==MC_MODE){mc.mode=(mc.mode+3+value%3)%3;mc.seq_on=0;mc_reset();mc.page=MC_HOME;}
 if(kind==MC_TEMPO){int n=mc.bpm+value;mc.bpm=n<40?40:n>160?160:n;}
 if(kind==MC_RESTART){mc_reset();mc.page=MC_PLAY;mc.running=1;if(mc.countin)mc.beat=-4000;}
 if(kind==MC_THEME)mc.theme=(mc.theme+12+value%12)%12;
 if(kind==MC_COUNTIN)mc.countin=!mc.countin;
 if(kind==MC_SOUND)mc.sound=(mc.sound+MC_SOUNDS+value%(int)MC_SOUNDS)%MC_SOUNDS;
 if(kind==MC_VOLUME){int n=mc.volume+value;mc.volume=n<0?0:n>64?64:n;}
 if(kind==MC_KEYBOARD){mc.keyboard_smk=!!value;if(!value&&mc.lesson>=47){mc.lesson=0;mc_reset();mc.seq_on=0;mc.page=MC_HOME;}}
 if(kind==MC_SHUTTLE&&value){
  int32_t end=mc_at(mc_current()->count-1),pos=mc.beat+value*1000;
  mc.beat=pos<0?0:pos>end?end:pos;mc.remainder=0;mc.index=0;
  while(mc.index+1<mc_current()->count&&mc_at(mc.index)<mc.beat)mc.index++;
  mc.hits=mc.misses=mc.wrong=mc.combo=mc.best_combo=mc.score=mc.feedback=0;
  mc.seeked=1;mc.seek_serial++;mc.page=MC_PLAY;
 }
}
static void mc_advance(uint32_t now){
 if(!mc.initialized)mc_init(now);
 while(mc_qread!=mc_qwrite){unsigned r=mc_qread&15;mc_apply(mc_queue[r].kind,mc_queue[r].value);mc_qread++;}
 uint32_t dt=now-mc.last_ms;mc.last_ms=now;if(!mc.running)return;if(dt>250)dt=250;
 uint32_t total=dt*mc.bpm+mc.remainder;mc.beat+=total/60;mc.remainder=total%60;
 const mc_lesson *l=mc_current();
 if(mc.mode==MC_LEARN&&mc.index<l->count&&mc.beat>mc_at(mc.index))mc.beat=mc_at(mc.index);
 if(mc.mode==MC_RHYTHM)while(mc.index<l->count&&mc.beat>mc_at(mc.index)+260){mc.misses++;mc.combo=0;mc.index++;mc.feedback=2;mc.flash_until=now+450;}
 if(mc.mode==MC_DEMO){mc.index=0;while(mc.index<l->count&&mc.beat>=mc_at(mc.index+1))mc.index++;}
 if(mc.index>=l->count&&mc.beat>=mc_at(l->count)){mc.running=0;mc.page=MC_RESULT;unsigned stars=mc_stars();if(stars>mc.best[mc.lesson])mc.best[mc.lesson]=stars;}
}
static void mc_key(unsigned note,unsigned velocity,uint32_t now){
 if(note>=128)return;
 unsigned was=mc.held[note];mc.held[note]=!!velocity;
 if(velocity)mc.boot_muted=1;
 if(!velocity||was||mc.app_mode||!mc.running||mc.page!=MC_PLAY||mc.mode==MC_DEMO||mc.beat<0||mc.index>=mc_current()->count||mc_current()->kind==2||(mc_current()->kind==1&&note>=53))return;
 const mc_step *s=&mc_current()->steps[mc.index];int delta=mc.beat-mc_at(mc.index);if(delta < -260)return;
 unsigned match=0,all=1;for(unsigned i=0;i<s->count;i++){match|=s->note[i]==note;all&=mc.held[s->note[i]];}
 if(!match){mc.wrong++;mc.combo=0;mc.feedback=2;mc.flash_until=now+400;return;}
 if(!all)return;
 mc.hits++;mc.combo++;if(mc.combo>mc.best_combo)mc.best_combo=mc.combo;mc.score+=100+10*(mc.combo>10?10:mc.combo);mc.index++;mc.feedback=1;mc.flash_until=now+450;
}
/* The synth adapter queries this mask; Demo notes never enter mc_key. */
static uint32_t mc_demo_mask(void){if(mc_current()->kind||!mc.running||mc.mode!=MC_DEMO||mc.index>=mc_current()->count)return 0;int32_t t=mc.beat-mc_at(mc.index);const mc_step *s=&mc_current()->steps[mc.index];if(t<0||t>=s->beats*250-100)return 0;uint32_t mask=0;for(unsigned i=0;i<s->count;i++)mask|=1u<<(s->note[i]-48);return mask;}
static unsigned mc_key_light(unsigned key,uint32_t now){
 unsigned age=now-mc.boot_ms,phase=(age/65)%52,pos=phase<27?phase:52-phase;
 if(mc.held[53+key])return 3;
 if(mc.lightshow&&(age<2200||mc.app_mode==MC_PSYCHEDELIC))return key==pos||key==26-pos?3:(key+27-pos)%27<4?1:0;
 if(mc.lightshow&&mc.app_mode==MC_JAM)return key==(now/180)%27?1:0;
 if(mc.page==MC_PLAY&&mc.index<mc_current()->count)for(unsigned j=0;j<mc_current()->steps[mc.index].count;j++)if(mc_current()->steps[mc.index].note[j]==53+key)return 2;
 return 0;
}
static uint32_t mc_pad_rgb(unsigned pad,uint32_t now){
 unsigned age=now-mc.boot_ms,lit=(mc.pads_held&(1u<<pad))||(mc.pad_flash[pad]&&now-mc.pad_flash[pad]<180);
 /* Outside an explicit light show, only the sounding pad lights. Stable blue
  * feedback makes any physical stray green pulse distinguishable from hue animation. */
 if(lit)return (uint32_t)mc.brightness;
 if(!mc.lightshow||mc.boot_muted||age>=2200){
  if(!mc.lightshow||mc.app_mode!=MC_PSYCHEDELIC)return 0;
 }
 unsigned hue=((mc.lightshow?now/8:0)+pad*47+mc.theme*64+mc.drum_bank*200)%768,sector=hue/128,f=hue%128;
 unsigned level=lit?8:age<2200?((pad+16-(age/75)%16)%16<5?6:1):mc.app_mode==MC_PSYCHEDELIC?2+mc.energy/48:mc.app_mode==MC_JAM?2:1;
 if(!mc.lightshow&&!lit)level=1;
 if(level>8)level=8;
 level=level*mc.brightness/8;
 unsigned a=level,b=level*f/128,c=level-b,r=0,g=0,bl=0;
 switch(sector){case 0:r=a;g=b;break;case 1:r=c;g=a;break;case 2:g=a;bl=b;break;case 3:g=c;bl=a;break;case 4:r=b;bl=a;break;default:r=a;bl=c;break;}
 return r<<16|g<<8|bl;
}

/* Pad steps are edited on the same consumer as the sequencer clock. */
static void mc_train_toggle(unsigned pad){
 if(pad>=16||mc.app_mode||mc_current()->kind!=2||mc.mode==MC_DEMO)return;
 if(mc.page==MC_RESULT)return;
 mc.page=MC_PLAY;mc.train_pattern[mc.train_lane]^=1u<<pad;
 unsigned correct=0;for(unsigned i=0;i<4;i++)correct+=mc.train_pattern[i]==mc_current()->target[i];
 mc.hits=correct;mc.score=correct*100;
 if(correct==4){mc.page=MC_RESULT;mc.seq_on=0;mc.best[mc.lesson]=3;}
}
