/* SPDX-License-Identifier: GPL-3.0-only
 * Original MusicCoach layout; uses Felucca's canvas/font primitives.
 * Three strips fit the existing 240 x 124 scratch canvas on both devices.
 */
static uint16_t mc_bg,mc_card,mc_ink,mc_muted,mc_pop,mc_pink,mc_blue;
#include "musiccoach_brand.h"
static const uint8_t mc_accents[12][3]={{255,82,105},{116,255,214},{214,255,82},{255,189,76},{186,134,255},{112,219,255},{255,141,75},{64,183,255},{221,122,255},{175,255,65},{255,145,192},{244,247,239}};
static void mc_colors(void){
 ux.mono=0;ux.light=mc.surface==1;ux.gen++;
 mc_bg=RGB(13,16,36);mc_card=RGB(29,34,61);mc_ink=RGB(244,247,239);mc_muted=RGB(153,174,199);
 const uint8_t *a=mc_accents[mc.theme];mc_pop=RGB(a[0],a[1],a[2]);mc_pink=RGB(255,112,171);mc_blue=RGB(112,187,255);
 if(mc.surface==1){mc_bg=RGB(239,242,249);mc_card=RGB(216,224,239);mc_ink=RGB(19,26,44);mc_muted=RGB(66,78,97);mc_pop=RGB(a[0]/3,a[1]/3,a[2]/3);mc_pink=RGB(151,30,71);mc_blue=RGB(20,92,158);}
 if(mc.surface==2){mc_bg=mc_card=RGB(0,0,0);mc_ink=mc_muted=RGB(255,255,255);mc_pop=RGB(255,255,0);mc_pink=RGB(255,128,224);mc_blue=RGB(0,255,255);}
}
static uint16_t mc_finger(unsigned f){return f==1?mc_pop:f==2?RGB(255,207,85):f==3?mc_pink:f==4?mc_blue:RGB(189,139,255);}
static void mc_label(int x,int y,const char *text,uint16_t color){cv_text_on(x,y,&AF_S,text,color,mc_bg);}
static void mc_num(char *b,unsigned n){fmt_int(b,(int)n);}
static void mc_star(int x,int y,int r,uint16_t color){cv_line(x-r,y,x+r,y,color);cv_line(x,y-r,x,y+r,color);cv_line(x-r/2,y-r/2,x+r/2,y+r/2,color);cv_line(x-r/2,y+r/2,x+r/2,y-r/2,color);}
static void mc_face(int x,int y,unsigned happy){
 int bob=(fm1_ms/130)%6;bob=bob<3?bob:5-bob;
 uint16_t ink=RGB(13,16,36);
 /* One stem and one curved flag make the mascot an eighth note. */
 cv_rrect(x+4,y+14+bob,35,25,12,mc_pop,mc_bg);
 cv_rect(x+33,y-8+bob,5,34,mc_pop);
 cv_line(x+36,y-8+bob,x+48,y+bob,mc_pop);cv_line(x+37,y-6+bob,x+48,y+2+bob,mc_pop);
 cv_line(x+48,y+bob,x+49,y+9+bob,mc_pop);cv_line(x+49,y+9+bob,x+43,y+14+bob,mc_pop);
 unsigned blink=(fm1_ms/180)%23==0;
 cv_rrect(x+12,y+22+bob,3,blink?1:5,1,ink,mc_pop);cv_rrect(x+26,y+21+bob,3,blink?1:5,1,ink,mc_pop);
 cv_line(x+17,y+30+bob,x+21,y+(happy?33:30)+bob,ink);cv_line(x+21,y+(happy?33:30)+bob,x+25,y+29+bob,ink);
 cv_rect(x+9,y+29+bob,3,2,mc_pink);cv_rect(x+30,y+28+bob,3,2,mc_pink);
 cv_line(x+3,y+24+bob,x-5,y+17-bob,mc_pop);cv_line(x+37,y+25+bob,x+46,y+19-bob,mc_pop);
}
static void mc_whistle(int x,int y,unsigned big){const uint16_t *p=big?mc_whistle_large:mc_whistle_small;unsigned w=big?64:25,h=big?52:20;for(unsigned row=0;row<h;row++)for(unsigned col=0;col<w;col++)cv_pset(x+col,y+row,p[row*w+col]);}
static void mc_tempo_icon(int x,int y){uint16_t c=RGB(244,247,239);cv_line(x+4,y,x,y+12,c);cv_line(x+4,y,x+10,y+12,c);cv_line(x,y+12,x+10,y+12,c);cv_line(x+5,y+10,x+10,y+2,mc_pop);cv_rect(x+8,y+3,3,3,mc_pop);}
static void mc_title(void){char b[16];uint16_t bg=RGB(13,16,36);cv_begin(240,28,bg);for(unsigned y=0;y<12;y++)for(unsigned x=0;x<15;x++)cv_pset(6+x,7+y,mc_whistle_small[(y*20/12)*25+x*25/15]);cv_text_on(27,7,&AF_S,"Music",RGB(255,255,255),bg);cv_text_on(62,7,&AF_S,"Coach",RGB(255,82,105),bg);
#if MUSICCOACH_DUAL_CORE
cv_text_on(122,7,&AF_S,audio_worker_online?"DUAL":"SAFE",RGB(153,174,199),bg);
#endif
mc_tempo_icon(187,7);mc_num(b,mc.bpm);cv_text_r(231,5,&AF_S,b,RGB(244,247,239),bg);cv_blit(0,0);}
static void mc_draw_home(void){
 const mc_lesson *l=mc_current();char b[16];
 cv_begin(240,116,mc_bg);
 for(int i=0;i<8;i++)mc_star(12+(i*31)%220,9+(i*23)%68,2,i%2?mc_blue:mc_pink);
 mc_face(24,18,1);cv_text_on(90,16,&AF_L,"LET'S",mc_ink,mc_bg);cv_text_on(90,46,&AF_L,"JAM!",mc_pop,mc_bg);
 cv_rrect(10,82,220,30,7,mc_card,mc_bg);mc_num(b,mc.lesson+1);cv_text_on(19,89,&AF_S,b,mc_pop,mc_card);cv_text_fit(41,88,&AF_M,l->title,mc_ink,mc_card,177);cv_blit(0,28);
 cv_begin(240,96,mc_bg);mc_label(13,5,l->hint,mc_muted);
 const char *modes[]={"LEARN","RHYTHM","DEMO"};
 for(unsigned i=0;i<3;i++){uint16_t c=i==mc.mode?mc_pop:mc_card;cv_rrect(10+75*i,29,70,25,5,c,mc_bg);cv_text_in(10+75*i,35,70,&AF_S,modes[i],i==mc.mode?mc_bg:mc_muted,c);}
 for(unsigned i=0;i<3;i++)mc_star(19+16*i,69,4,i<mc.best[mc.lesson]?mc_pop:mc_card);
 cv_text_r(227,62,&AF_S,mc_sounds[mc.sound],mc_muted,mc_bg);
 cv_text_in(0,79,240,&AF_S,mc.countin?"PLAY / COUNT-IN ON":"PLAY / COUNT-IN OFF",mc_pop,mc_bg);cv_blit(0,144);
}
static void mc_draw_result(void){
 char b[24];cv_begin(240,116,mc_bg);mc_face(99,10,1);
 cv_text_in(0,58,240,&AF_L,mc.mode==MC_DEMO?"NICE LISTEN!":"YOU MADE IT!",mc_ink,mc_bg);
 for(unsigned i=0;i<3;i++)mc_star(89+31*i,99,10,i<mc_stars()?mc_pop:mc_card);cv_blit(0,28);
 cv_begin(240,96,mc_bg);mc_num(b,mc.score);cv_text_on(18,2,&AF_L,b,mc_pop,mc_bg);mc_num(b,mc_accuracy());unsigned len=str_len(b);b[len]='%';b[len+1]=0;cv_text_r(220,2,&AF_L,b,mc_blue,mc_bg);
 mc_label(18,33,"POINTS",mc_muted);cv_text_r(220,33,&AF_S,"ACCURACY",mc_muted,mc_bg);
 mc_label(18,57,mc.mode==MC_DEMO?"NOW TRY LEARN MODE":"PLAY AGAIN / BEAT YOUR BEST",mc_ink);
 cv_text_in(0,80,240,&AF_S,"PLAY: AGAIN    HOME: LESSONS",mc_pop,mc_bg);cv_blit(0,144);
}
/* Full instrument keyboard: 16 white keys on FM-1, 22 on SMK37. */
static unsigned mc_low(void){return mc.keyboard_smk?48:53;}
static unsigned mc_keys(void){return mc.keyboard_smk?37:27;}
static int mc_black(unsigned n){unsigned p=n%12;return p==1||p==3||p==6||p==8||p==10;}
static int mc_white_count(void){return mc.keyboard_smk?22:16;}
static int mc_white_before(unsigned note){int w=0;for(unsigned n=mc_low();n<note;n++)w+=!mc_black(n);return w;}
static int mc_center(unsigned note){int w=mc_white_before(note),total=mc_white_count();return 8+(mc_black(note)?w*224/total:(w*224/total+(w+1)*224/total)/2);}
/* Original 3x5 pitch glyphs keep sharps readable in narrow black-key lanes. */
static void mc_micro(int x,int y,char c,uint16_t color){
 static const uint16_t digits[]={0x7b6f,0x2492,0x73e7,0x73cf,0x5bc9,0x79cf,0x79ef,0x7249,0x7bef,0x7bcf};
 static const uint16_t letters[]={0x2bed,0x6bae,0x7927,0x6b6e,0x79a7,0x79a4,0x796f};
 uint16_t bits=c>='0'&&c<='9'?digits[c-'0']:c>='A'&&c<='G'?letters[c-'A']:c=='#'?0x5f7d:0;
 for(int row=0;row<5;row++)for(int col=0;col<3;col++)if(bits&(1u<<(14-row*3-col)))cv_rect(x+col,y+row,1,1,color);
}
static char mc_letter(unsigned n){static const char letters[]="CCDDEFFGGAAB";return letters[n%12];}
static void mc_draw_keyboard(void){char b[4];
 cv_begin(240,60,mc_bg);
 for(unsigned n=mc_low();n<mc_low()+mc_keys();n++)if(!mc_black(n)){
  int w=mc_white_before(n),x=8+w*224/mc_white_count(),end=8+(w+1)*224/mc_white_count();
  uint16_t color=mc.held[n]?mc_pop:RGB(244,247,239);cv_rect(x,0,end-x-1,53,color);
  b[0]=mc_letter(n);b[1]=0;cv_text_in(x,32,end-x-1,&AF_S,b,RGB(13,16,36),color);
  mc_micro((x+end)/2-1,47,'0'+n/12-1,RGB(13,16,36));
 }
 for(unsigned n=mc_low();n<mc_low()+mc_keys();n++)if(mc_black(n)){
  int center=mc_center(n),width=mc.keyboard_smk?6:8;uint16_t color=mc.held[n]?mc_pop:RGB(13,16,36);
  cv_rect(center-width/2,0,width,32,color);uint16_t ink=mc.held[n]?RGB(13,16,36):RGB(244,247,239);
  mc_micro(center-1,12,mc_letter(n),ink);mc_micro(center-1,19,'#',ink);mc_micro(center-1,26,'0'+n/12-1,ink);
 }
 cv_rect(8,57,224,2,mc_card);cv_rect(8,57,224*(mc.app_mode?mc.jam_step:mc.index)/(mc.app_mode?16:mc_current()->count),2,mc_blue);cv_blit(0,180);
}
static void mc_draw_play(void){
 const mc_lesson *l=mc_current();char b[24];
 cv_begin(240,40,mc_bg);cv_text_fit(11,0,&AF_M,l->title,mc_ink,mc_bg,219);
 mc_num(b,mc.score);mc_label(12,22,!mc.running?"PAUSED":b,mc_pop);
 for(unsigned f=1;f<=5;f++){cv_rect(64+f*12,22,9,12,mc_finger(f));mc_micro(67+f*12,26,'0'+f,RGB(13,16,36));}
 cv_text_r(229,22,&AF_S,mc_sounds[mc.sound],mc_muted,mc_bg);cv_blit(0,28);
 /* Fall area ends directly at the tall piano keys: no separate PLAY D4 row. */
 cv_begin(240,112,mc_bg);cv_rect(8,0,224,112,mc_card);
 for(unsigned n=mc_low();n<mc_low()+mc_keys();n++){
  if(!mc_black(n))cv_rect(8+mc_white_before(n)*224/mc_white_count(),0,1,112,RGB(42,49,77));
 }
 for(unsigned i=mc.index;i<l->count;i++){
  int y=109-(mc_at(i)-mc.beat)*56/1000;if(y<0||y>128)continue;
  const mc_step *step=&l->steps[i];for(unsigned k=0;k<step->count;k++){
   unsigned n=step->note[k];int center=mc_center(n),sharp=mc_black(n);
   int width=sharp?8:224/mc_white_count()-2;if(width<7)width=7;
   int x=center-width/2;uint16_t color=mc_finger(step->finger[k]);
   cv_rrect(x,y-19,width,20,2,color,mc_card);
   mc_micro(center-(sharp?3:1),y-16,mc_letter(n),mc_bg);
   if(sharp)mc_micro(center+1,y-16,'#',mc_bg);
   mc_micro(center-1,y-8,'0'+n/12-1,mc_bg);
  }
 }
 cv_rect(8,110,224,2,mc_pop);
 if(mc.feedback==1&&fm1_ms<mc.flash_until)for(unsigned i=0;i<6;i++)mc_star(20+i*39,70-(int)((fm1_ms+i*29)%300)/12,2,i%2?mc_pink:mc_pop);
 if(mc.beat<0){mc_num(b,(unsigned)(-mc.beat+999)/1000);cv_rrect(94,33,52,49,10,mc_pop,mc_card);cv_text_in(94,41,52,&AF_L,b,mc_bg,mc_pop);}
 cv_blit(0,68);
 mc_draw_keyboard();
}
#include "musiccoach_visuals.c"
static void musiccoach_draw(void){cv_oy=0;mc_colors();if(!mc.boot_muted&&fm1_ms-mc.boot_ms<1800){mc_draw_startup();return;}mc_title();if(mc.settings)mc_draw_settings();else if(mc.app_mode==MC_PSYCHEDELIC)mc_draw_psychedelic();else if(mc.app_mode==MC_JAM)mc_draw_jam();else if(mc.page==MC_HOME)mc_draw_home();else if(mc.page==MC_RESULT)mc_draw_result();else {if(mc_current()->kind==2)mc_draw_sequence();else if(mc_current()->kind==1)mc_draw_drums();else mc_draw_play();if(fm1_ms<mc.controls_until)mc_draw_control_strip();}}
