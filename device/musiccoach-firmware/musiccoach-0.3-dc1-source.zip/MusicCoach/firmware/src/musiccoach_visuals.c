/* SPDX-License-Identifier: GPL-3.0-only */
/* Strip rendering stays within Felucca's existing canvas allocation. */
static void mc_draw_control_strip(void){
 cv_begin(240,40,mc_bg);char b[24];
 for(unsigned k=0;k<4;k++){cv_text_in(k*60,2,60,&AF_S,mc_param_names[mc.fxpage][k],mc_muted,mc_bg);mc_param_text(mc.fxpage,k,b);cv_text_fit(k*60+3,19,&AF_S,b,mc_pop,mc_bg,55);}cv_blit(0,28);
}
static void mc_draw_startup(void){
 mc_title();for(int strip=0;strip<2;strip++){
  cv_begin(240,106,mc_bg);cv_oy=-strip*106;
  for(unsigned i=0;i<12;i++)mc_star(14+(i*37)%210,18+(i*43)%155,2,i%2?mc_pink:mc_blue);
  mc_face(91,49,1);cv_text_in(0,114,240,&AF_L,"LET'S PLAY!",mc_ink,mc_bg);
  cv_text_in(0,159,240,&AF_S,"SMALL NOTES. BIG JOY.",mc_pop,mc_bg);
  cv_rect(35,193,170*(fm1_ms-mc.boot_ms)/1800,3,mc_pop);cv_oy=0;cv_blit(0,28+strip*106);
 }
}
static void mc_draw_settings(void){
 static const char *const surfaces[]={"DARK","LIGHT","HIGH CONTRAST"};
 const char *labels[]={"K1 / THEME","K2 / APPEARANCE","K3 / LIGHT SHOW","K4 / BRIGHTNESS"};
 char b[12];mc_num(b,mc.brightness);const char *values[]={mc_themes[mc.theme],surfaces[mc.surface],mc.lightshow?"ON":"OFF",b};
 for(int strip=0;strip<2;strip++){
  cv_begin(240,106,mc_bg);cv_oy=-strip*106;
  for(unsigned i=0;i<4;i++){int y=5+42*i;cv_rrect(9,y,222,38,5,mc_card,mc_bg);cv_text_on(17,y+3,&AF_S,labels[i],mc_muted,mc_card);cv_text_on(17,y+18,&AF_M,values[i],mc_pop,mc_card);}
  mc_label(12,179,mc.drumview?"DRUM ANIMATION: ON":"DRUM ANIMATION: OFF",mc_ink);mc_label(12,195,"SEQ: DRUM VIEW / HOME: EXIT",mc_muted);
  cv_oy=0;cv_blit(0,28+strip*106);
 }
}
static void mc_drum_picture(int x,int y,unsigned pad,int radius){
 unsigned age=1000;uint16_t mask=pad==0?0x4001:pad==1?0x8106:pad==5?0x00e0:0x3e18;
 for(unsigned k=0;k<16;k++)if((mask&(1u<<k))&&mc.pad_flash[k]&&fm1_ms-mc.pad_flash[k]<age)age=fm1_ms-mc.pad_flash[k];
 unsigned hit=age<180;
 int bounce=hit?(180-age)/45:0;uint16_t color=hit?mc_pop:mc_blue;
 cv_rrect(x-radius,y-8+bounce,2*radius,19,radius/2,mc_card,mc_bg);
 cv_rrect(x-radius,y-11+bounce,2*radius,12,6,color,mc_bg);
 cv_line(x-radius+3,y+11,x-radius,y+19,mc_muted);cv_line(x+radius-3,y+11,x+radius,y+19,mc_muted);
 if(hit){mc_star(x-radius-3,y-13,3,mc_pink);mc_star(x+radius+4,y-15,3,mc_pop);}
}
static void mc_draw_drums(void){
 const mc_lesson *l=mc_current();char b[16];
 cv_begin(240,106,mc_bg);cv_text_fit(10,0,&AF_M,l->title,mc_ink,mc_bg,220);
 mc_num(b,mc.score);mc_label(10,21,mc.running?b:"PAUSED",mc_pop);
 if(mc.beat<0){mc_num(b,(-mc.beat+999)/1000);cv_text_in(0,47,240,&AF_L,b,mc_pop,mc_bg);}
 else if(mc.index<l->count){
  const mc_step *s=&l->steps[mc.index];for(unsigned i=0;i<s->count;i++){unsigned pad=s->note[i]-36;cv_text_in(i*80,44,80,&AF_S,mc_pad_names[pad],mc_pop,mc_bg);mc_num(b,pad+1);cv_text_in(i*80,63,80,&AF_L,b,mc_ink,mc_bg);}
 }
 cv_rect(8,100,224*mc.index/l->count,3,mc_pop);cv_blit(0,28);
 cv_begin(240,106,mc_bg);
 if(mc.drumview){mc_drum_picture(32,25,0,22);mc_drum_picture(91,22,1,20);mc_drum_picture(150,24,5,19);mc_drum_picture(207,20,3,21);}
 for(unsigned p=0;p<16;p++){int x=8+(p%8)*28,y=mc.drumview?64+(p/8)*20:12+(p/8)*40;unsigned target=0;
  if(mc.index<l->count)for(unsigned j=0;j<l->steps[mc.index].count;j++)target|=l->steps[mc.index].note[j]==36+p;
  uint16_t c=mc.pad_flash[p]&&fm1_ms-mc.pad_flash[p]<180?mc_pink:target?mc_pop:mc_card;cv_rrect(x,y,25,18,3,c,mc_bg);mc_num(b,p+1);cv_text_in(x,y+2,25,&AF_S,b,target?mc_bg:mc_ink,c);
 }cv_blit(0,134);
}
static void mc_draw_sequence(void){
 static const char *const lanes[]={"KICK","SNARE","HATS","CLAP"};
 for(int strip=0;strip<2;strip++){
  cv_begin(240,106,mc_bg);cv_oy=-strip*106;
  cv_text_fit(8,0,&AF_M,mc_current()->title,mc_ink,mc_bg,224);
  mc_label(8,24,"OUTLINES = TARGET / PADS = STEPS",mc_muted);
  for(unsigned lane=0;lane<4;lane++){
   int y=47+lane*31;mc_label(8,y,lanes[lane],lane==mc.train_lane?mc_pop:mc_muted);
   uint16_t pattern=mc.mode==MC_DEMO?mc_current()->target[lane]:mc.train_pattern[lane];
   for(unsigned i=0;i<16;i++){int x=66+i*10;unsigned target=mc_current()->target[lane]&(1u<<i),set=pattern&(1u<<i);cv_rect(x,y,8,16,target?mc_pop:mc_card);cv_rect(x+1,y+1,6,14,set?mc_pink:mc_bg);if(mc.seq_on&&mc.jam_step==i)cv_rect(x,y+18,8,2,mc_blue);}
  }
  mc_label(8,178,mc.seq_on?"PLAYING / DRUMS + MELODY":"PLAY TO HEAR DRUMS + MELODY",mc_pop);
  mc_label(8,196,"ARROWS: LANE / REC: CLEAR",mc_muted);cv_oy=0;cv_blit(0,28+strip*106);
 }
}
static void mc_draw_jam(void){
 cv_begin(240,112,mc_bg);cv_text_on(12,6,&AF_L,"JAM",mc_pop,mc_bg);cv_text_r(227,15,&AF_M,mc_sounds[mc.sound],mc_ink,mc_bg);
 cv_text_on(12,43,&AF_M,mc_fxpages[mc.fxpage],mc_pink,mc_bg);
 char b[24];for(unsigned k=0;k<4;k++){cv_text_in(k*60,68,60,&AF_S,mc_param_names[mc.fxpage][k],mc_muted,mc_bg);mc_param_text(mc.fxpage,k,b);cv_text_fit(k*60+3,86,&AF_S,b,mc_pop,mc_bg,55);}cv_blit(0,28);
 cv_begin(240,40,mc_bg);for(unsigned i=0;i<16;i++)cv_rrect(8+i*14,8,11,14,2,mc.seq_on&&mc.jam_step==i?mc_pop:mc_card,mc_bg);cv_text_in(0,25,240,&AF_S,mc.seq_on?"GROOVE RUNNING":"PLAY / START YOUR GROOVE",mc_muted,mc_bg);cv_blit(0,140);mc_draw_keyboard();
}
static int mc_sin(unsigned p){return SINE[p&1023];}
static void mc_draw_psychedelic(void){
 unsigned t=fm1_ms/9,scene=(fm1_ms/16000)%3;
 for(int strip=0;strip<2;strip++){
  cv_begin(240,106,mc_bg);cv_oy=-strip*106;
  /* Moving starfield, a perspective tunnel, and two rotating ribbon scenes. */
  for(unsigned i=0;i<38;i++){int x=(i*71+t*(1+i%3)/6)%240,y=(i*43+t*(1+i%2)/9)%212;mc_star(x,y,i%5==0?1:0,i%3?mc_muted:mc_pop);}
  for(unsigned ring=0;ring<9;ring++){
   int radius=12+(ring*13+t%13),cx=120+mc_sin(t+ring*22)/1900,cy=98+mc_sin(t/2+256+ring*19)/2300;
   if(scene==1)radius=20+ring*9+mc.energy/10;
   int px=0,py=0;
   for(unsigned i=0;i<=24;i++){
    unsigned a=i*1024/24+t/3+ring*(scene==2?29:3);
    int x=cx+mc_sin(a)*radius/32768,y=cy+mc_sin(a+256)*(scene==1?radius/3:radius)/32768;
    if(scene==2)y+=mc_sin(a*3+t)/4000;
    if(scene==0&&ring>0&&i%3==0){int inner=radius-13;cv_line(cx+(x-cx)*inner/radius,cy+(y-cy)*inner/radius,x,y,mc_blue);}
    if(i){cv_line(px,py+1,x,y+1,mc_card);cv_line(px,py,x,y,ring%3==0?mc_pink:ring%3==1?mc_pop:mc_blue);}px=x;py=y;
   }
  }
  cv_rect(0,184,240,28,mc_bg);cv_text_in(0,190,240,&AF_S,(const char *const[]){"NEON HORIZON","ORBITAL RIBBONS","THOUGHT VORTEX"}[scene],mc_pop,mc_bg);
  cv_rect(8,208,224*mc.energy/255,2,mc_pink);cv_oy=0;cv_blit(0,28+strip*106);
 }
 if(fm1_ms<mc.controls_until)mc_draw_control_strip();
}
