# MusicCoach native candidate 0.2

Update: the dedicated MusicCoach USB installer and opt-in 0.3 dual-core candidates
are documented in [MUSICCOACH_USB.md](MUSICCOACH_USB.md). The compile-only SMK
limitations below describe the original 0.2 build, not the new USB candidate.

MusicCoach runs directly on Felucca's SMK37 and FM-1 foundation. The local
browser simulator at http://localhost:8802/musiccoach.html runs the same C
lesson, drawing and audio code. The original multi-instrument web app remains
separate at http://localhost:8798 and is linked in the simulator header.

## Practice and play

- Coach is the default; Jam plays live sounds and a melodic sequence;
  Psychedelic renders three changing audio-reactive tunnel/ribbon scenes.
- 87 built-in studies: 47 piano, 36 drums, four sequencer workshops. The browser
  compendium searches titles, skills and instructions, with instrument, level
  and category filters. Both instruments have primers, technique, phrases,
  etudes and song arrangements; drums also have sticking rudiments and fills.
- Learn waits for correct notes/pads, Rhythm keeps time, Demo plays without
  progress credit. Sequencer workshops use 16 pad steps across kick, snare,
  hats and clap, then mix those lanes with a melodic part. All four target
  patterns must match to complete. Demo auditions target patterns.
- The piano curriculum fits FM-1 F3-G5 and SMK C3-C6. FM-1 selects the 47 piano
  studies; drum/sequencer training uses SMK pads or the browser pad grid.
- The 240x240 display shows all 27/37 keys, 53px tall white keys, 32px black
  keys, pitch names inside compact falling notes, finger colors and a small
  1-5 color legend. Fingerings are suggestions, not hand-tracking judgments.
- SMK pads play two banks of 16 velocity-sensitive ADPCM samples: Pocket and
  Neon. Samples are synthesized/rendered using the retained GPL Felucca wave
  generator, not recordings of an acoustic kit. Closed hats choke open hats.
- Animated drum groups react to every pad; the browser has a larger illustrated
  drum kit and training cues beside its pads. Settings can hide the animation.
- Startup has an eighth-note mascot, brief melody and pad/key light chase.
  The red whistle is from the original MusicCoach web app. Branding is
  MusicCoach, without a version number in the logo.
- Twelve palettes coordinate the FM-1, SMK Pro and Elite visual style; Dark,
  Light and High Contrast are separate choices. Pad light levels retain the
  inherited hardware current ceiling. FM-1 key light brightness is limited to
  the board's existing discrete LED levels, with zero fully off.

## Controls

| Action | SMK37 | FM-1 |
| --- | --- | --- |
| Volume / playing sound / lesson / shuttle | K1 / K2 / K3 / K4 | K1 / K2 / K3 / K4 |
| Four performance parameters | K5-K8 | EDIT held + K1-K4 |
| Performance page | FX or knob-bank | FX |
| Coach / Jam / Psychedelic | Globe | Glo |
| Learn / Rhythm / Demo | Seq in Coach | Seq in Coach |
| Play / restart | Play / Record | Play / Record |
| Home / exit settings | Patch | Home |
| Tempo | Octave down/up | SELECT |
| Count-in | PARA | ENV |
| Drum bank | Fader-bank | Not applicable |
| Settings | BT button (radio remains disabled) | SAVE |
| Settings parameters | K1 theme, K2 appearance, K3 lights, K4 brightness | Same |
| Drum animation setting | Seq while Settings is open | Seq while Settings is open |
| Sequencer trainer lane | Previous/next arrows | Not applicable |

Performance pages are FX (drive/chorus/delay/reverb), LFO (rate/wave/pitch/filter),
ARP (mode/rate/octave/gate), SCALE (root/scale/quantize/transpose), CHORD
(chord/voicing/root/spread), NOTE REPEAT (enable/rate/gate/hold), SEQUENCER
(play/pattern/rate/swing). K2 selects piano, electric piano, organ, synth,
flute or sax. Sequencer Record clears a workshop pattern. K4 moves by a beat
in piano/drum lessons and by a step in Jam/sequencer mode.

Browser keys A W S E D F T G Y H U J K play C4-C5. Mouse dragging or touch
swiping across keys glides between notes; pointer capture, cancellation,
window blur and shared-note ownership prevent stuck notes. Pads support
pointer and keyboard activation, selectable velocity and note repeat.

## Scope and limitations

This is a local development candidate, not a published firmware release.
No MusicCoach image has been flashed or validated on a physical device.
SMK output is a raw compile-only image, explicitly NOT FOR INSTALL; packaging,
model-specific recovery and device testing remain. The FM-1 updater package
is a local test candidate. SMK Elite-specific hardware behavior is unverified.

Stars and MusicCoach preferences are RAM/session-only. Browser accounts,
imports and library sync belong to the separate main web app. Native wire
command IDs and stored Felucca layouts are unchanged. SMK flash writes remain
disabled. The browser uses the SMK audio adapter even when displaying FM-1.
Count-in is four clicks at a new lesson/restart; resuming a pause continues
from its position. Seeking resets scoring and cannot award full-song stars.

The compendium consists of compact original studies and simplified
public-domain melody excerpts; it is not an exhaustive catalog of published
etudes or the complete set of acoustic drum rudiments. Drum scoring checks
pads and timing, not physical sticking technique, rebound or dynamics.

## Rebuild and verification

```sh
python tools/gen_musiccoach_library.py
python tools/gen_musiccoach_drums.py
python tools/gen_musiccoach_brand.py
python tools/build_smk37_browser.py --zig /path/to/zig
python tools/build_smk37.py
python tools/build.py --release 0.2-coach --sdk /path/to/ac79-sdk
python tools/serve_smk37.py --port 8802

gcc -std=c11 -Wall -Wextra -Werror -Wno-unused-function tests/musiccoach_test.c -o /tmp/musiccoach-test
/tmp/musiccoach-test
node web/audio/test_musiccoach.mjs
node --check web/musiccoach-preview.js
```

Dependencies remain JieLi toolchain, AC79 SDK for FM-1, Python Pillow with
libraqm/fontTools, and Zig. Build configuration enables MUSICCOACH on this
isolated branch. Do not use the old Felucca Studio with this private browser
status schema. The generated curriculum JSON and C header come from one source.

Verification on 2026-10-12/13:

- Portable C suite: all 87 studies complete correctly; wrong pads, simultaneous
  chords, fresh repeated hits, timing, pause/count-in, demo exclusions, seeking,
  sound/volume bounds, full sequencer pattern completion and RGB light ceilings.
- Native WebAssembly: both keyboard layouts, all six sounds, all 32 drum samples,
  K1-K4, FX change, Jam playback, three views, drum grading/demo, four-lane
  sequencer completion, Dark/Light/High Contrast render captures.
- Browser: combined text/level filtering, practice launch, pad score feedback,
  mouse gliding with all notes released, and animation/appearance settings.
  Touch uses the same Pointer Events path; physical touch hardware is untested.
- Hardware compilers: SMK raw image 503,212 bytes; FM-1 package passes image/RAM,
  RAM-call and register-access checks. One inherited SMK unused trim-CRC warning.
- Physical boot, lights, knob timing, audio stability and visualizer load remain
  untested. No flash, push, deployment or upstream contribution in this round.

Candidate checksums and filenames are recorded in
`build/musiccoach-0.2/manifest.json`. Native/browser screenshots are in
`build/coach-preview/`.

## Provenance and future replacement

Branch: `feat/musiccoach-piano`, isolated worktree `MusicCoach-firmware`.
Base: `cc13e146f11d93328b4fc13ec92c4d69f6bc6e76` from the local Felucca SMK
repository. It retains upstream Felucca 1.5.1 at
`a4d7ca2e5d52a4c35e2468401f00d883cadbda03`, the committed SMK HAL, MIDI ownership,
sustain, boot/update infrastructure, fonts, sample engine and piano assets.
Uncommitted work in the original Felucca and MusicCoach web repositories was
not imported. Experimental Bluetooth work was not added.

Original modules are `musiccoach.h` (lessons/state/scoring),
`musiccoach_draw.c` (layout) and `musiccoach_runtime.c` (Felucca sound adapter).
Board adapters map controls to the lesson command queue. Sloop source was read
for visual direction; no Sloop source or artwork was copied. Felucca licenses,
credits and asset notices remain. This derivative is GPL-3.0-only.

This is not a clean-room implementation. A future independent replacement
needs a separate specification and implementation process; these module
boundaries make replacement easier but do not establish clean-room provenance.
No upstream contribution, push or publication has been made for this work.
