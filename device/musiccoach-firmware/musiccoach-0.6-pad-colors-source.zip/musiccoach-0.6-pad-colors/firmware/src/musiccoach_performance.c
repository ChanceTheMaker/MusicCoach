/* SPDX-License-Identifier: GPL-3.0-only
 * MusicCoach control pages use Felucca parameters; no new stored protocol IDs.
 * Included after seq.c, so all mutations run on its audio consumer.
 */
enum { MCP_REPEAT=250, MCP_RUN, MCP_PATTERN };
static const uint8_t mc_param[7][4]={
 {P_DIST,P_CHOR,P_DLY,P_REV},{P_LRATE,P_LWAVE,P_LD_PIT,P_LD_FLT},
 {P_AMODE,P_ARATE,P_AOCT,P_AGATE},{P_ROOT,P_SCALE,P_QUANT,P_TRANS},
 {P_CHRD,P_VOIC,P_ROOT,P_SPRD},{MCP_REPEAT,P_ARATE,P_AGATE,P_AHOLD},
 {MCP_RUN,MCP_PATTERN,P_SDIV,P_SSWING}};
static const char *const mc_param_names[7][4]={
 {"DRIVE","CHORUS","DELAY","REVERB"},{"RATE","WAVE","PITCH","FILTER"},
 {"MODE","RATE","OCTAVE","GATE"},{"ROOT","SCALE","SNAP","SHIFT"},
 {"CHORD","VOICING","ROOT","SPREAD"},{"REPEAT","RATE","GATE","HOLD"},
 {"PLAY","PATTERN","RATE","SWING"}};
static int mc_param_value(unsigned page,unsigned knob){
 unsigned p=mc_param[page][knob];return p==MCP_REPEAT?trk[0].p[P_AMODE]==AM_REPEAT:p==MCP_RUN?mc.seq_on:p==MCP_PATTERN?mc.seq_pattern:trk[0].p[p];
}
static void mc_param_text(unsigned page,unsigned knob,char *b){
 unsigned p=mc_param[page][knob];int v=mc_param_value(page,knob);
 if(p==MCP_REPEAT||p==MCP_RUN)str_cpy(b,v?"ON":"OFF",24);
 else if(p==MCP_PATTERN)str_cpy(b,(const char *const[]){"SONG","PULSE","REVERSE","CHORDS"}[v],24);
 else {const char *unit;param_format(&TP[p],v,b,&unit);}
}
static void mc_pattern_load(void){
 track_t *t=&trk[0];const mc_lesson *l=mc_current()->kind?&mc_lessons[3]:mc_current();
 for(unsigned i=0;i<NSTEP;i++){
  step_t *s=&t->step[i];memset(s,0,sizeof *s);s->time=ST_REST;if(i>=16)continue;
  unsigned at=mc.seq_pattern==2?l->count-1-i%l->count:i%l->count;
  const mc_step *src=&l->steps[at];s->time=ST_NOTE;s->vel=i%4?85:110;
  s->n=mc.seq_pattern==3?3:src->count;
  for(unsigned n=0;n<s->n;n++)s->note[n]=mc.seq_pattern==3?60+(unsigned[]){0,4,7}[n]:src->note[n];
  if(mc.seq_pattern==1){s->n=1;s->note[0]=i%4==3?67:60;}
 }
 t->p[P_SLEN]=16;
}
static void mc_performance_tick(void){
 static unsigned lesson=255,pattern=255,restart,view;
 song.g[G_BPM]=mc.bpm;
 for(unsigned page=0;page<7;page++)for(unsigned knob=0;knob<4;knob++){
  int d=mc.fx_delta[page][knob];mc.fx_delta[page][knob]=0;if(!d)continue;
  unsigned p=mc_param[page][knob];
  if(p==MCP_RUN){mc.seq_on=d>0;continue;}
  if(p==MCP_PATTERN){mc.seq_pattern=clamp((int)mc.seq_pattern+d,0,3);continue;}
  if(p==MCP_REPEAT){trk[0].p[P_AMODE]=d>0?AM_REPEAT:AM_OFF;continue;}
  trk[0].p[p]=clamp(trk[0].p[p]+d,TP[p].min,TP[p].max);
 }
 if(lesson!=mc.lesson||pattern!=mc.seq_pattern){lesson=mc.lesson;pattern=mc.seq_pattern;mc_pattern_load();}
 if(!mc.app_mode&&mc_current()->kind!=2){mc.seq_on=0;if(song.playing)seq_stop();}
 else if(mc.seq_on&&!song.playing)seq_start();else if(!mc.seq_on&&song.playing)seq_stop();
 if(restart!=mc.seq_restart){restart=mc.seq_restart;if((mc.app_mode||mc_current()->kind==2)&&mc.seq_on)seq_start();}
 if(mc.seq_seek){int at=clamp((int)trk[0].seq_idx+mc.seq_seek,0,15);seq_release(&trk[0]);trk[0].seq_idx=(at+15)%16;trk[0].seq_pos=0x7fffffff;mc.seq_seek=0;}
 if(view!=mc.app_mode){if(!view||!mc.app_mode)for(unsigned i=0;i<NTRK;i++)arp_off(&trk[i]);view=mc.app_mode;}
 mc.jam_step=(uint8_t)(trk[0].seq_idx%16);
}

#if MUSICCOACH_SMK
#include "musiccoach_drum_data.h"
typedef struct { uint32_t pos,sample;int32_t pred,prior;int16_t index;uint8_t velocity,phase; } mc_drum_voice;
static mc_drum_voice mc_drums[16];
static uint8_t mc_pad_velocity[16];
static uint32_t mc_pad_repeat_at[16];
static void mc_drum_hit(unsigned pad,unsigned velocity){
 mc_visual_attack(pad,velocity,1,fm1_ms);
 if(pad==3)mc_drums[4].velocity=0; /* closed hat chokes open hat */
 mc_drums[pad]=(mc_drum_voice){.sample=mc.drum_bank*16+pad,.velocity=velocity};
 mc.pad_flash[pad]=fm1_ms|1u;
}
static void musiccoach_pad(unsigned pad,unsigned velocity){
 if(pad>=16)return;
 if(!mc.app_mode&&mc_current()->kind==2){if(velocity&&!(mc.pads_held&(1u<<pad)))mc_train_toggle(pad);if(velocity)mc.pads_held|=1u<<pad;else mc.pads_held&=~(1u<<pad);return;}
 if(mc_current()->kind==1)mc_key(36+pad,velocity,fm1_ms);
 if(velocity){mc.boot_muted=1;mc.pads_held|=1u<<pad;mc_pad_velocity[pad]=velocity;mc_pad_repeat_at[pad]=fm1_ms;mc_drum_hit(pad,velocity);}
 else mc.pads_held&=~(1u<<pad);
}
static void musiccoach_drum_mix(uint32_t n){
 if(trk[0].p[P_AMODE]==AM_REPEAT){unsigned interval=div_samples(trk[0].p[P_ARATE])*1000u/FS;if(!interval)interval=1;
  for(unsigned k=0;k<16;k++)if((mc.pads_held&(1u<<k))&&fm1_ms-mc_pad_repeat_at[k]>=interval){mc_pad_repeat_at[k]=fm1_ms;mc_drum_hit(k,mc_pad_velocity[k]);}
 }
 for(unsigned k=0;k<16;k++){
  mc_drum_voice *v=&mc_drums[k];if(!v->velocity)continue;
  for(unsigned i=0;i<n;i++){
   if(!v->phase){
    if(v->pos>=MC_DRUM_SAMPLES[v->sample].n){v->velocity=0;break;}
    unsigned code=(MC_DRUM_DATA[MC_DRUM_SAMPLES[v->sample].off+v->pos/2]>>(4*(v->pos&1)))&15;v->pos++;
    int step=IMA_STEP[v->index],d=step/8;v->prior=v->pred;
    if(code&4)d+=step;
    if(code&2)d+=step/2;
    if(code&1)d+=step/4;
    v->pred=clamp(v->pred+((code&8)?-d:d),-32768,32767);v->index=clamp(v->index+IMA_IDX[code&7],0,88);
   }
   int value=(v->phase?v->pred:(v->pred+v->prior)/2)*v->velocity/381;v->phase^=1;
   mix_l[i]+=value;mix_r[i]+=value;send_r[i]+=value*trk[0].p[P_REV]/127;send_d[i]+=value*trk[0].p[P_DLY]/127;
  }
 }
 unsigned peak=0;for(unsigned i=0;i<n;i++){unsigned v=(unsigned)(mix_l[i]<0?-mix_l[i]:mix_l[i]);if(v>peak)peak=v;}
 mc.energy=(uint8_t)clamp(((unsigned)mc.energy*15+peak/96)/16,0,255);
}
#else
static void musiccoach_pad(unsigned pad,unsigned velocity){(void)pad;(void)velocity;}
static void musiccoach_drum_mix(uint32_t n){unsigned peak=0;for(unsigned i=0;i<n;i++){unsigned v=(unsigned)(mix_l[i]<0?-mix_l[i]:mix_l[i]);if(v>peak)peak=v;}mc.energy=(uint8_t)clamp(((unsigned)mc.energy*15+peak/96)/16,0,255);}
#endif

static void mc_training_audio(void){
 mc.jam_step=(uint8_t)(trk[0].seq_idx%16);
#if MUSICCOACH_SMK
 static int last=-1,lesson=-1,serial=-1;int current=-1;
 if(!mc.app_mode&&mc_current()->kind==1&&mc.running&&mc.mode==MC_DEMO&&mc.index<mc_current()->count&&mc.beat>=mc_at(mc.index))current=mc.index;
 if(current>=0&&(current!=last||lesson!=mc.lesson||serial!=mc.seek_serial)){
  const mc_step *step=&mc_current()->steps[current];for(unsigned k=0;k<step->count;k++)mc_drum_hit(step->note[k]-36,100);
 }
 last=current;lesson=mc.lesson;serial=mc.seek_serial;
 static int seqstep=-1;int step=song.playing?trk[0].seq_idx:-1;
 if(!mc.app_mode&&mc_current()->kind==2&&step>=0&&step<16&&step!=seqstep){
  static const unsigned pads[]={0,1,3,2};
  for(unsigned k=0;k<4;k++)if((mc.mode==MC_DEMO?mc_current()->target[k]:mc.train_pattern[k])&(1u<<step))mc_drum_hit(pads[k],step%4?90:115);
 }
 seqstep=step;
#endif
}
