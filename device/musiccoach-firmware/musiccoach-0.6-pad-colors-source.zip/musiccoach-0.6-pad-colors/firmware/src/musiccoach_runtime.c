/* SPDX-License-Identifier: GPL-3.0-only
 * Narrow Felucca adapter: sound setup and demo-note ownership.
 * Lesson state and drawing are maintained in separate MusicCoach modules.
 */
#include "musiccoach_performance.c"
static unsigned mc_loaded_sound;
static void musiccoach_load_sound(void){
 static const uint8_t engines[]={ENGI_SAMPLE,ENGI_FM6,7,0,ENGI_SAMPLE,ENGI_SAMPLE};
 static const uint8_t presets[]={0,0,0,5,2,3};
 unsigned engine=engines[mc.sound],preset=presets[mc.sound];
 const preset_t *p=&ENGINES[engine]->presets[preset];
 for(unsigned i=0;i<NTRK;i++){
  track_t *t=&trk[i];t->eng_req=engine;t->preset=preset;t->user=0;
  for(unsigned j=0;j<8;j++)t->p[P_E0+j]=p->e[j];
  for(unsigned j=0;j<4;j++)t->p[P_ATK+j]=p->env[j];
  t->p[P_ED_FLT]=p->fenv;t->p[P_VOICE]=V_POLY;
 }
 mc_loaded_sound=mc.sound;panic_req=(1u<<NTRK)-1;
}
static void musiccoach_sound_init(void){
 mc_init(fm1_ms);song.sel=0;song.octave=0;song.playing=song.rec=0;
 for(unsigned i=0;i<NTRK;i++){
  track_t *t=&trk[i];const preset_t *p=&ENGINES[ENGI_SAMPLE]->presets[0];
  t->eng_req=ENGI_SAMPLE;t->preset=0;t->user=0;
  for(unsigned j=0;j<P_E0;j++)t->p[j]=TP[j].def;
  for(unsigned j=0;j<8;j++)t->p[P_E0+j]=p->e[j];
  for(unsigned j=0;j<4;j++)t->p[P_ATK+j]=p->env[j];
  t->p[P_VOICE]=V_POLY;t->p[P_AMODE]=t->p[P_CHRD]=t->p[P_QUANT]=t->p[P_TRANS]=0;
  t->p[P_LEVEL]=100;t->p[P_REV]=20;t->p[P_DLY]=0;
  for(unsigned j=0;j<NSTEP;j++)t->step[j].time=ST_REST;
 }
 musiccoach_load_sound();
}
static void musiccoach_audio_tick(void){
 static uint32_t sounded;static int last_click=-1;static uint8_t seek_serial;
 mc_advance(fm1_ms);
 mc_performance_tick();
 song.master_q12=mc.volume*64u;
 if(mc_loaded_sound!=mc.sound||seek_serial!=mc.seek_serial){
  for(unsigned i=0;i<32;i++)if(sounded&(1u<<i))midi_note_event(0,48+i,0);
  sounded=0;seek_serial=mc.seek_serial;
  if(mc_loaded_sound!=mc.sound){musiccoach_load_sound();return;}
 }
 int beat=mc.running&&mc.beat<0?(mc.beat+4000)/1000:-1;
 if(beat>=0&&beat!=last_click)click_req=beat==0?2:1;
 last_click=beat;
 uint32_t wanted=mc_demo_mask(),age=fm1_ms-mc.boot_ms;
 if(!mc.boot_muted&&age>=180&&age<1600){
  unsigned step=(age-180)/240;static const uint8_t notes[]={72,76,79,76,72,72};
  if((age-180)%240<190)wanted|=1u<<(notes[step]-48);
 }
 uint32_t change=sounded^wanted;
 for(unsigned i=0;i<32;i++)if(change&(1u<<i))midi_note_event(0,48+i,wanted&(1u<<i)?85:0);
 sounded=wanted;
}
