/* SPDX-License-Identifier: GPL-3.0-only */
/* Sample voices own their decoder/filter state; track parameters and sample
 * data stay read-only for the entire block. Render into private buffers and
 * add in original voice order. Other engines retain their serial renderer. */
#if MUSICCOACH_DUAL_CORE
typedef struct {
    track_t *track;
    voice_t *voice;
    vmod_t mod;
    uint32_t n;
    int32_t pcm[CTL];
} mc_voice_job_t;
static mc_voice_job_t mc_voice_job;
static int32_t mc_voice_second[CTL];
static void mc_voice_render(void *context)
{
    mc_voice_job_t *j=context;
    for(unsigned k=0;k<j->n;k++) j->pcm[k]=0;
    sample_render(j->track,j->voice,j->pcm,j->n,&j->mod);
}
static void mc_voice_add(int32_t *to,const int32_t *from,unsigned n)
{
    for(unsigned k=0;k<n;k++) to[k]+=from[k];
}
#endif
