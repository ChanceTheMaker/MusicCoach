"""Original compact practice curriculum; one source for firmware and browser."""
from pathlib import Path
import json
ROOT = Path(__file__).resolve().parents[1]
items = []
def add(title, instrument, category, level, notes, aim, tip, beats=4, sticking='', targets=None):
    steps = []
    for n in notes:
        ns = n if isinstance(n, list) else [n]
        steps.append({'notes': ns, 'duration': beats})
    items.append(dict(id=len(items), title=title, instrument=instrument, category=category,
        level=level, aim=aim, tip=tip, sticking=sticking, steps=steps,
        bpm=60 if level=='Beginner' else 80 if level=='Intermediate' else 100,
        targets=targets or [0x1111,0x1010,0x5555,0x1000],
        credit='MusicCoach original study'))
def piano(t,c,l,n,a,tip,b=4): add(t,'Piano',c,l,n,a,tip,b)
def drum(t,c,l,p,a,tip,b=4,sticking=''):
    add(t,'Drums',c,l,[[36+x for x in n] if isinstance(n,list) else 36+n for n in p],a,tip,b,sticking)
piano('First Spark','Primer','Beginner',[60,62,64,65,67,65,64,62,60],'Find the five-finger C position.','Use right-hand fingers 1 2 3 4 5, then return. Keep your wrist loose.')
piano('Scale Surfer','Scales','Beginner',[60,62,64,65,67,69,71,72,71,69,67,65,64,62,60],'Connect an octave of C major.','Right hand ascending: 1 2 3, thumb under, 1 2 3 4 5.')
piano('Chord Crew','Chords','Beginner',[[60,64,67],[60,65,69],[59,62,67],[60,64,67]],'Hear a I-IV-V-I progression.','Land all three notes together. Release fully before the next chord.',8)
piano('Arpeggio Orbit','Arpeggios','Beginner',[60,64,67,72,67,64,60,64,67,72,67,60],'Turn a chord into a flowing line.','Prepare the next finger before releasing the current note.')
piano('Minor Mood','Chords','Beginner',[[57,60,64],[57,62,65],[56,59,64],[57,60,64]],'Hear Am-Dm-E-Am.','Listen for the raised G-sharp in the E major chord.',8)
piano('Pocket Pulse','Rhythm','Beginner',[60,60,67,67,65,64,62,60],'Repeat without holding through the next beat.','Lift between repeated notes; aim for equal space and sound.')
piano('Left Hand Lift','Primer','Beginner',[53,55,57,58,60,58,57,55,53],'Build left-hand independence.','Use fingers 5 4 3 2 1 ascending, then reverse.')
piano('Star Trip','Songs','Beginner',[60,60,67,67,69,69,67,65,65,64,64,62,62,60],'Play the opening of Twinkle, Twinkle, Little Star.','Sing the phrase first. Hold its final notes for two beats.')
for i in (6,13): items[7]['steps'][i]['duration']=8
items[7]['credit']='Traditional public-domain melody; MusicCoach pocket arrangement'
for name,notes in [('C',[60,62,64,65,67]),('D minor',[62,64,65,67,69]),('G',[55,57,59,60,62]),('F',[53,55,57,58,60]),('A minor',[57,59,60,62,64])]:
    piano(name+' Five-Finger Flow','Technique','Beginner',notes+notes[-2::-1],'Keep a relaxed five-finger shape.','First use Learn, then Rhythm. Repeat with an even touch.')
for name,notes in [('G major',[55,57,59,60,62,64,66,67]),('F major',[53,55,57,58,60,62,64,65]),('D major',[62,64,66,67,69,71,73,74]),('A natural minor',[57,59,60,62,64,65,67,69]),('A harmonic minor',[57,59,60,62,64,65,68,69]),('D natural minor',[62,64,65,67,69,70,72,74]),('C pentatonic',[60,62,64,67,69,72]),('A blues',[57,60,62,63,64,67,69])]:
    piano(name+' Trail','Scales','Intermediate',notes+notes[-2::-1],'Learn the scale shape and its characteristic tones.','Start slowly; use the same fingering each pass.',2)
piano('Chromatic Ladder','Scales','Intermediate',list(range(60,73))+list(range(71,59,-1)),'Connect adjacent semitones.','Use finger 3 on black keys and thumb on most white keys.',2)
for name,ch in [('C',[60,64,67]),('F',[60,65,69]),('G',[59,62,67]),('A minor',[57,60,64]),('D minor',[57,62,65])]:
    piano(name+' Broken Shapes','Arpeggios','Intermediate',ch+ch[::-1]+[ch[0],ch[2],ch[1],ch[2]]*2,'Change direction without a gap.','Group each chord shape mentally. Avoid twisting your wrist.',2)
for name,chords in [('Major Inversions',[[60,64,67],[64,67,72],[55,60,64],[60,64,67]]),('Minor Inversions',[[57,60,64],[60,64,69],[64,69,72],[57,60,64]]),('Seventh Shells',[[60,64,70],[53,57,63],[55,59,65],[60,64,70]]),('Suspended Colors',[[60,62,67],[60,65,67],[60,64,67],[60,62,67]]),('Diminished Steps',[[59,62,65],[62,65,68],[65,68,71],[59,62,65]])]:
    piano(name,'Chords','Intermediate',chords*2,'Move between compact voicings.','Notice common tones. Aim for simultaneous attacks and quiet releases.',8)
for name,notes,tip in [
 ('Thirds in Motion',[60,64,62,65,64,67,65,69,67,71,69,72],'Hear each rising third before playing.'),
 ('Alberti Lantern',[60,67,64,67,60,67,64,67,60,69,65,69,59,67,62,67],'Keep the top repeated tone light.'),
 ('Contrary Conversation',[[53,72],[55,71],[57,69],[58,67],[60,65],[58,67],[57,69],[55,71]],'Use one hand for each line; move outward and inward together.'),
 ('Broken Octave Flight',[60,72,64,76,62,74,65,77,64,76,62,74,60,72,60,72],'Prepare each leap with a relaxed lateral motion.'),
 ('Syncopation Study',[60,67,64,62,65,69,67,60],'Count subdivisions aloud; do not chase the notes.'),
 ('Sequence in Sixteenths',[60,62,64,62,62,64,65,64,64,65,67,65,65,67,69,67],'Practice one four-note cell before linking them.'),
 ('Two-Hand Chord Reply',[[53,60,65],[55,59,62],[57,60,64],[55,60,64]]*3,'Play the bottom note with the left hand; upper pair with the right.'),
 ('Chromatic Approach',[61,62,66,67,70,71,71,72,66,67,63,64,59,60,59,60],'Let the chromatic note resolve into the next tone.')]:
    piano(name,'Etudes','Advanced',notes,'Build control inside a short musical study.',tip,1 if 'Sixteenths' in name else 2)
for i,step in enumerate(items[-4]['steps']): step['duration']=[3,1,2,2][i%4]
for name,notes in [('Blues Question',[60,63,65,66,67,63,60,60]),('Pentatonic Answer',[69,67,64,62,60,62,64,60]),('Minor Turn',[69,71,72,71,69,68,69,64]),('Jazz Enclosure',[65,63,64,68,66,67,73,71,72,67,64,60])]:
    piano(name,'Phrases','Intermediate',notes,'Shape a short musical sentence.','Sing it, play it, then improvise a different ending.',2)
for name,notes in [('Ode to Joy',[64,64,65,67,67,65,64,62,60,60,62,64,64,62,62]),('Frere Jacques',[60,62,64,60,60,62,64,60,64,65,67,64,65,67]),('When the Saints',[60,64,65,67,60,64,65,67,60,64,65,67,64,60,64,62])]:
    piano(name+' - Theme','Songs','Beginner',notes,'Learn a recognizable melody in a compact range.','This is a short practice arrangement. Learn the contour, then shape the phrase.')
    items[-1]['credit']='Public-domain melody; MusicCoach simplified pocket arrangement'
drum('Kick Pulse','Primer','Beginner',[0]*8,'Place the kick on a steady pulse.','Tap pad 1 with alternating hands. Release after every hit.')
drum('Backbeat Basics','Grooves','Beginner',[0,1]*4,'Alternate kick and snare.','Count 1 2 3 4; snare answers the kick.')
drum('Hat Coordination','Coordination','Beginner',[[0,3],3,[1,3],3]*4,'Combine hats with kick and snare.','Two highlighted pads mean a simultaneous hit.',2)
drum('First Tom Fill','Fills','Beginner',[5,5,6,6,7,7,1,2],'Travel across the toms.','Keep the spacing even as your hands move.',2)
for name,st,b,l in [('Single Stroke Roll','RLRLRLRL',2,'Beginner'),('Double Stroke Roll','RRLLRRLL',2,'Beginner'),('Single Paradiddle','RLRRLRLL',2,'Beginner'),('Reverse Paradiddle','RRLRLLRL',2,'Intermediate'),('Inward Paradiddle','RLLRLRRL',2,'Intermediate'),('Double Paradiddle','RLRLRRLRLRLL',2,'Intermediate'),('Triple Paradiddle','RLRLRLRRLRLRLRLL',1,'Advanced'),('Paradiddle Diddle','RLRRLLRLRRLL',1,'Advanced'),('Five Stroke Roll Grid','RRLLRLLRRL',1,'Intermediate'),('Six Stroke Roll Grid','RLLRRL RLLRRL'.replace(' ',''),1,'Advanced'),('Nine Stroke Roll Grid','RRLLRRLLRLLRRLLRRL',1,'Advanced')]:
    drum(name,'Rudiments',l,[1 if h=='R' else 8 for h in st]*2,'Practice the sticking: '+st+'.','Right hand on Snare, left on Rim. These are separate pad attacks, not a buzz-roll simulation. Keep doubles even.',b,st)
for name,p,b,l in [
 ('Four on the Floor',[[0,3],3,[0,1,3],3]*4,2,'Beginner'),
 ('Eighth-Note Rock',[[0,3],3,[1,3],3,[0,3],3,[1,3],3]*2,2,'Beginner'),
 ('Open Hat Lift',[[0,3],3,[1,3],4]*4,2,'Intermediate'),
 ('Disco Lift',[[0,3],4,[0,1,3],4]*4,2,'Intermediate'),
 ('Half-Time Pocket',[[0,3],3,3,3,[1,3],3,[0,3],3]*2,2,'Intermediate'),
 ('Offbeat Kick',[[0,3],3,[1,3],0,3,[0,3],[1,3],3]*2,2,'Intermediate'),
 ('Ride Pocket',[[0,11],11,[1,11],11]*4,2,'Intermediate'),
 ('Funk Sixteenths',[[0,3],3,3,0,[1,3],3,0,3]*2,1,'Advanced'),
 ('Linear Groove',[0,3,1,3,0,3,0,1,3,0,3,1,3,0,1,3],1,'Advanced'),
 ('Cowbell Conversation',[[0,9],9,[1,9],9,0,9,[1,9],2]*2,2,'Advanced'),
 ('Tom Trip Around',[5,6,7,1]*4,1,'Intermediate'),
 ('Snare to Toms',[1,1,1,1,5,5,6,6,7,7,6,6,5,1,2,10],1,'Intermediate'),
 ('Kick Fill Exchange',[0,1,0,5,0,6,0,7]*2,1,'Advanced'),
 ('Paradiddle Orchestration',[3,1,3,3,1,3,1,1]*2,1,'Advanced'),
 ('Three over Four Accent Cycle',[1,3,3]*8,2,'Advanced')]:
    drum(name,'Fills' if 'Fill' in name or 'Toms' in name or 'Tom Trip' in name else 'Grooves',l,p,'Keep a steady pulse through a changing pattern.','Start in Learn. Move to Rhythm when each combination feels natural. Increase tempo only after three clean runs.',b)
drum('Pocket Conversation','Phrases','Intermediate',[0,1,3,3,0,1,5,2]*2,'Play a question and a tom-fill answer.','Make the second half feel like a reply to the first.',2)
drum('Linear Call and Reply','Phrases','Advanced',[0,3,1,3,0,3,1,0,3,1,5,6,7,1,2,10],'Connect a groove to a melodic drum phrase.','Use the same pulse through the final fill.',1)
drum('Coordination Circuit','Etudes','Intermediate',[[0,3],3,[1,3],3,[0,11],11,[1,11],11,0,5,1,6,0,7,1,10],'Change from hats to ride to toms without losing time.','Practice each four-hit cell, then link all four cells.',2)
drum('Linear Weave Study','Etudes','Advanced',[0,3,1,3,5,0,6,1,3,0,7,1,3,2,0,10]*2,'Move a sixteenth-note line across the kit.','One pad per subdivision; keep each sound balanced.',1)
drum('Neon Walk - Original Song','Songs','Beginner',[[0,3],3,[1,3],3]*4+[5,5,6,6,7,7,1,10]+[[0,3],3,[1,3],3]*4,'Perform a short A-fill-A drum arrangement.','First 16 hits: groove. Next eight: fill. Return to the groove at the same tempo.',2)
drum('Midnight Circuit - Original Song','Songs','Advanced',[0,3,1,3,0,3,0,1]*4+[5,1,6,1,7,0,2,10]+[[0,11],11,[1,11],11]*4,'Perform a linear verse, fill, and ride-cymbal chorus.','Learn each section independently before the full Rhythm run.',1)
for name,targets,level in [('Groove Builder',[0x1111,0x1010,0x5555,0x1000],'Beginner'),('Offbeat Workshop',[0x1141,0x1010,0xaaaa,0x0400],'Intermediate'),('Funk Assembly',[0x4149,0x1010,0xffff,0x0800],'Advanced'),('Sparse Pocket',[0x0101,0x1000,0x4444,0x0010],'Intermediate')]:
    add(name,'Together','Sequencer',level,[60,64,67,72]*4,'Build four drum lanes and play them with a melodic sequence.','Choose Kick, Snare, Hats or Clap. Lit outlines are the target; pads toggle steps 1-16. Play auditions the whole pattern. Match all four lanes to complete.',targets=targets)
# Finger suggestions are study data, never inferred by the renderer.
for it in items:
    notes=[s['notes'][0] for s in it['steps']]
    unique=sorted(set(n for s in it['steps'] for n in s['notes']))
    for i,step in enumerate(it['steps']):
        if len(step['notes'])==3: fingers=[1,3,5]
        elif len(step['notes'])==2: fingers=[5,1]
        elif 'Chromatic' in it['title']:
            n=step['notes'][0];fingers=[3 if n%12 in (1,3,6,8,10) else 2 if n%12 in (0,5) else 1]
        else:
            rank=unique.index(step['notes'][0]);fingers=[([1,2,3,1,2,3,4,5][rank%8] if len(unique)>5 else min(rank+1,5))]
        step['fingers']=fingers
# Explicit introductory fingerings, including left hand and arpeggio turns.
for idx,fingers in {0:[1,2,3,4,5,4,3,2,1],1:[1,2,3,1,2,3,4,5,4,3,2,1,3,2,1],3:[1,2,3,5,3,2,1,2,3,5,3,1],5:[1,1,5,5,4,3,2,1],6:[5,4,3,2,1,2,3,4,5],7:[1,1,4,4,5,5,4,3,3,2,2,1,1,1]}.items():
    for step,f in zip(items[idx]['steps'],fingers): step['fingers']=[f]
assert len(items)<256
lines=['/* SPDX-License-Identifier: GPL-3.0-only */','/* Generated by tools/gen_musiccoach_library.py; do not hand edit. */']
for it in items:
    steps=[]
    for s in it['steps']:
        ns=s['notes']; fingers=s['fingers']
        steps.append('{{'+','.join(map(str,ns+[0]*(3-len(ns))))+'},{'+','.join(map(str,fingers+[0]*(3-len(ns))))+'},'+str(len(ns))+','+str(s['duration'])+'}')
    lines.append('static const mc_step mc_lib_%d[]={%s};'%(it['id'],','.join(steps)))
lines.append('static const mc_lesson mc_lessons[]={')
for it in items:
    lines.append('{%s,%s,mc_lib_%d,%d,%d,%d,{%s}},'%(json.dumps(it['title'].upper()),json.dumps((it['level']+' / '+it['category']).upper()),it['id'],len(it['steps']),min(n for s in it['steps'] for n in s['notes']),{'Piano':0,'Drums':1,'Together':2}[it['instrument']],','.join(map(str,it['targets']))))
lines.append('};')
(ROOT/'firmware/src/musiccoach_library.h').write_text('\n'.join(lines)+'\n',encoding='utf-8')
(ROOT/'web/musiccoach-library.json').write_text(json.dumps(items,indent=2)+'\n',encoding='utf-8')
print(f'Generated {len(items)} lessons: '+', '.join(f'{k} {sum(i["instrument"]==k for i in items)}' for k in ['Piano','Drums','Together']))
