#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
# Offline only. No physical MIDI or flash access.
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/coach-dual-tests
cc -std=gnu11 -O1 -w tests/audio_worker_test.c -o build/coach-dual-tests/worker
build/coach-dual-tests/worker
for mode in 0 1; do
  cc -std=gnu11 -DMUSICCOACH_DUAL_CORE=$mode tests/musiccoach_multicore_test.c -o build/coach-dual-tests/lifecycle
  build/coach-dual-tests/lifecycle
done
cc -std=gnu11 -O1 -w -fno-builtin -pthread -Ibuild/gen -Ifirmware/hal tests/musiccoach_render_worker_test.c -o build/coach-dual-tests/render
build/coach-dual-tests/render 0 build/coach-dual-tests/serial.pcm
build/coach-dual-tests/render 1 build/coach-dual-tests/parallel.pcm
cmp build/coach-dual-tests/serial.pcm build/coach-dual-tests/parallel.pcm
printf 'MusicCoach concurrent audio is byte-identical.\n'
