#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Rasterize MusicCoach's existing whistle SVG for the native LCD (Pillow/fontTools)."""
from pathlib import Path
import xml.etree.ElementTree as ET
from PIL import Image, ImageDraw
from fontTools.pens.basePen import BasePen
from fontTools.svgLib.path import parse_path

ROOT=Path(__file__).resolve().parents[1]
class Flatten(BasePen):
    def __init__(self): super().__init__(None);self.paths=[];self.points=[]
    def _moveTo(self,p): self.points=[p];self.paths.append(self.points)
    def _lineTo(self,p): self.points.append(p)
    def _curveToOne(self,a,b,c):
        p=self.points[-1]
        for i in range(1,25):
            t=i/24;u=1-t;self.points.append(tuple(u*u*u*p[k]+3*u*u*t*a[k]+3*u*t*t*b[k]+t*t*t*c[k] for k in range(2)))
    def _closePath(self): self.points.append(self.points[0])
    def _endPath(self): pass

def main():
    canvas=Image.new('RGB',(256,208),'#0d1024');d=ImageDraw.Draw(canvas)
    for e in ET.parse(ROOT/'web/musiccoach-whistle.svg').getroot():
        tag=e.tag.split('}')[-1];a=e.attrib
        if tag=='path':
            pen=Flatten();parse_path(a['d'],pen);paths=[[(round(x*4),round(y*4)) for x,y in p] for p in pen.paths]
            fill=a.get('fill','black');fill='#ed3e52' if fill.startswith('url') else fill
            for pts in paths:
                if fill!='none' and 'fill' in a:d.polygon(pts,fill=fill)
                if 'stroke' in a:d.line(pts,fill=a['stroke'],width=round(float(a.get('stroke-width',1))*4),joint='curve')
        elif tag=='ellipse':
            x,y,rx,ry=[float(a[k]) for k in ('cx','cy','rx','ry')]
            d.ellipse(((x-rx)*4,(y-ry)*4,(x+rx)*4,(y+ry)*4),fill=a.get('fill'),outline=a.get('stroke'),width=round(float(a.get('stroke-width',1))*4))
    lines=['/* Generated from web/musiccoach-whistle.svg by tools/gen_musiccoach_brand.py. */']
    for name,w,h in [('small',25,20),('large',64,52)]:
        im=canvas.resize((w,h),Image.Resampling.LANCZOS)
        vals=[((r>>3)<<11)|((g>>2)<<5)|(b>>3) for r,g,b in im.getdata()]
        lines.append(f'static const uint16_t mc_whistle_{name}[]={{')
        lines.extend(','.join(str(v) for v in vals[i:i+20])+',' for i in range(0,len(vals),20));lines.append('};')
    (ROOT/'firmware/src/musiccoach_brand.h').write_text('\n'.join(lines)+'\n')

if __name__=='__main__': main()
