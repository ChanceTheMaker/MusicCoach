#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Local MusicCoach 0.2 FM-1 USB handoff. Defaults to read-only identity."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import time
import fm1_install as wire

ROOT=Path(__file__).resolve().parents[1]
SHA='7b24e82aacc80ce8dd9966262768547b136732df3072d2329c59b88efb724d81'
PRODUCT='FM-1_902'

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--install',action='store_true')
    parser.add_argument('--yes',action='store_true')
    args=parser.parse_args()
    if args.install and not args.yes:parser.error('Installation requires --yes after the owner authorizes this exact candidate.')
    raw=(ROOT/'build/musiccoach-0.2/musiccoach-fm1-0.2.fwsc').read_bytes()
    if len(raw)!=610086 or hashlib.sha256(raw).hexdigest()!=SHA or wire.product_of(raw)!=PRODUCT:
        raise RuntimeError('The approved MusicCoach 0.2 package has changed. No device operation allowed.')
    wire.PORT_RE=re.compile(r'fm-1|doom|musiccoach|felucca|sloop|melodee|ota|composite|sinco|usb-midi',re.I)
    backend=wire.MidoBackend()
    # Avoid selecting one instrument from several; GS wavetable is output-only.
    if len(backend.input_names())!=1:raise RuntimeError('Connect only the target FM-1.')
    up=wire.Updater(backend)
    dev=up.find(lambda i:i.model in ('FM-1','Doom-FM-1','ota-Doom-FM-1'))
    if not dev:raise RuntimeError('No unambiguous updater-enabled FM-1 found. Use the browser for generic-loader model confirmation.')
    print('Connected:',dev.id.text,'on',dev.name,flush=True)
    if not args.install:dev.link.close();return
    image=wire.logical_image(raw)
    step=lambda *values:print(*values,flush=True)
    link=dev.link
    try:
        if dev.id.model=='Doom-FM-1':
            step('Entering Doom RAM loader')
            if not link.send(wire.UPGRADE):raise RuntimeError('Disconnected before handoff')
            link.close();link=None
            dev=up.wait_for(lambda i:i.model=='ota-Doom-FM-1',30)
            if not dev:raise RuntimeError('Doom loader did not appear. No application programming started.')
            link=dev.link
        elif dev.id.model=='FM-1':
            dev=up.check(dev,image,step);link=dev.link
            if dev.id.model!='ota-FM-1':raise RuntimeError('Unexpected loader identity')
        step('Writing MusicCoach 0.2',PRODUCT)
        last=[-1]
        def progress(phase,value=None):
            if phase!='write' or value!=last[0]:
                step(phase,value);last[0]=value
        up.write(dev,image,progress);link=None
        back=up.verify(PRODUCT,step)
        result=dict(installed=True,product=back,sha256=SHA,version='MusicCoach 0.2',dualCore=False,verifiedUsbRestart=True)
        (ROOT/'build/coach-preview/fm1-usb-result.json').write_text(json.dumps(result,indent=2)+'\n')
    finally:
        if link:link.close()

if __name__=='__main__':main()
