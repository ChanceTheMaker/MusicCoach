# MusicCoach USB installer and dual-core candidates

The dedicated local installer is `http://localhost:8802/musiccoach-install.html`.
The main MusicCoach app's device page links here. It never loads Felucca release
metadata or installs the Felucca application. Upstream credits remain intact.

## Candidates

- SMK 0.6 pad colors: `SMK-37_946`, dual-core, includes the 0.5 controls fixes.
  Each psychedelic hit captures its pad hue, retained by the held pad and
  fading LCD burst. The latest controls-test installer option now selects 0.6;
  existing 0.5 artifacts remain unchanged. Build with test number 46 and
  `--musiccoach-version MusicCoach-0.6-Pad-Colors`. All 16 pad/LCD hues and
  simultaneous hits pass WASM tests. Physical verification remains pending.

- SMK Pro / Elite 0.5 controls test: `SMK-37_945`, opt-in dual-core candidate
  including six reactive visual scenes, ordered/direct performance shortcuts,
  one-action-per-press handling, MusicCoach indicator state, isolated blue pad
  feedback, and trailing low reset bytes in LED transfers. Host tests pass;
  the neighboring-green-flash hardware report remains unverified. The local
  installer exposes this separately from the older candidates. Build with
  `MUSICCOACH_DUAL_CORE=1 python3 tools/build_smk37.py --public-release
  --usb-test-number 45 --musiccoach-version MusicCoach-0.5-Controls-Test`.

0.5 evidence: `web/audio/test_musiccoach_controls.mjs` covers queued Scale/Chord,
held Globe, Settings isolation, Home, transport indicators and all 16 RGB pad
outputs. The LED HAL test checks every RGB channel/pad, unrelated-pad zeros,
trailing reset bytes and SPI restore/timeout under ASan/UBSan. Existing WASM
lesson/visualizer tests, portable lessons and dual-core PCM equality pass.
Pro/Elite packages round-trip through the protected-byte/checksum checks and
reject corrupted apps and unknown identities. New packages and hashes are in
`build/musiccoach-0.5-controls/packages.json`; hardware validation is pending.

- FM-1 0.2: existing single-core candidate, identity `FM-1_902`. Its original
  package and source archive remain unchanged. It is the initially selected
  test build; selecting it does not authorize an installation.
- FM-1 0.3 dc1: identity `FM-1_903`, opt-in dual-core candidate.
- SMK Pro / Elite 0.3 dc1: identity `SMK-37_943`, opt-in dual-core candidate
  with the RAM USB updater enabled. The browser combines our application with
  the checksum-pinned official 016 file for the selected physical model.

All candidates require an explicit test-build acknowledgement and installation
click. Neither 0.3 candidate has physical-device validation. Do not describe
offline tests as hardware success or promote these to a published release.

### FM-1 installation, 2026-10-13

The owner authorized installing the checksum-pinned 0.2 single-core candidate
over USB, replacing Doom. Read-only discovery found `Doom-FM-1_015`. Chrome's
MIDI permission did not resolve, so the waiting browser attempt was closed and
the local updater was used. Its first process exited during USB re-enumeration,
before writing package data. A fresh identity query confirmed
`ota-Doom-FM-1_015`; the next explicit resume completed and confirmed the
restarted identity `FM-1_902`. Evidence is in
`build/coach-preview/fm1-usb-resume.log` and `fm1-usb-result.json`.
The owner subsequently confirmed: "Screen and sound both work." This verifies
the physical MusicCoach display and key sound for the installed 0.2 build.
Other controls and extended hardware testing remain pending; the candidate's
overall hardwareValidated flag remains false. No 0.3 dual-core or SMK candidate
was flashed.

## USB capabilities

The transport, progress and stock-restoration modules were ported from
`felucca-smk-usb-recovery` revision
`00197c1` (Felucca 0.9.24). They live under `web/musiccoach-usb/` so they do not
change the inherited Felucca site. This retains bounded, reply-based MIDI
discovery, handling for differently named input/output ports, ambiguity
rejection, port cleanup, loader reconnection, transfer byte accounting, and
completion only after the returned firmware identity matches.

FM-1 installation supports normal FM-1 firmware, updater-enabled Doom's
`Doom-FM-1` RAM handoff, and both active-loader identities. A bare `ota-FM-1`
identity requires physical-model confirmation because an Elite loader can use
that name. Doom versions without a USB updater need hardware recovery.

SMK installation retains automatic official-016 first install, compatible
Felucca/Sloop/Melodee/Doom updater handoff, active-loader resume, and explicit
Elite generic-loader confirmation. The 0.9.24 loader fix preserves an entirely
erased calibration sector as well as valid calibration; it rejects malformed
partial records and checks the entire sector after application programming.
Power-loss recovery may still require a hardware adapter.

Original-firmware restoration uses the same tested model-specific package and
transport code, including FM-1 V15 (user-supplied official file) and Pro/Elite
016 (automatic download or local file). It does not claim to recover old user
projects or factory presets. No write automatically retries after failure.

## Dual-core scope

MusicCoach adapts the guarded worker and CPU lifecycle from Sloop SMK revision
`203c30473592d48f5ec43b487ba394f7d5d6c760`, whose worker is derived from Melodee
dc7 (`ae898250699828ea728ab549b2ac1f99e69948c0`). These remain GPL-3.0 code.
The MusicCoach adaptation dispatches independent SAMPLE-engine voices (piano,
flute and sax) to CPU1 while CPU0 renders the next voice. It preserves voice
order and uses private output buffers. Other engines, drum pads, effects,
lessons, display, USB, storage, and all device controls remain on CPU0.
This does not double all-engine performance or change voice limits.

CPU1 has private 4 KiB user and supervisor stacks, a checked mailbox, an SRAM
idle loop and a bounded 10 ms join. Rejected mailboxes, faults or timeouts retire
the worker; a partly rendered voice block is dropped, never rendered twice.
Later blocks run serially. Retirement survives warm resets until cold power-on.
CPU1 is held before RAM initialization, fatal recovery and USB handoff.
The screen says DUAL when the worker is online and SAFE after fallback.
Browser audio remains single-threaded.

## Evidence and reproduction

- All six sounds exercised through real MusicCoach runtime with overlapping
  notes and sustain: 8,949 concurrent jobs; serial/concurrent PCM byte-identical.
- Worker busy/offline, corrupt mailbox, timeout wrap and fault retirement pass.
- Lifecycle cold/warm boot, failed handshake, retry, fault and updater stop pass.
- Target audit: 8,192 bytes of aligned CPU1 stacks, 41 SRAM poll instructions,
  one callback, no idle calls into XIP; protected flash helpers remain call-free.
- FM-1 app 489,756 bytes, RAM 55,780/73,728, pool including stacks 334,880/368,640.
- USB tests cover valid/corrupt packages, wrong board, cancelled generic loader,
  Doom handoff, active-loader resume, interrupted transfer and wrong restart.
- Original-firmware restore tests pass with local official FM-1, Pro and Elite
  fixtures; SMK updater tests pass protected-boundary and calibration cases.

Build with the existing documented compiler/SDK environment:

```
MUSICCOACH_DUAL_CORE=1 python3 tools/build.py --release 0.3-coachdc1
MUSICCOACH_DUAL_CORE=1 python3 tools/build_smk37.py --public-release --usb-test-number 43
```

Here `--public-release` selects the portable, owner-independent SMK layout; it
does not publish the firmware. The raw SMK application is never directly flashed.
The installer builds a verified model-specific package before allowing install.
