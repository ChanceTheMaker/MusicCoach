/* SPDX-License-Identifier: GPL-3.0-only */
/* Real SMK runtime + concurrent upstream worker. Run twice (0 and 1) and
 * compare PCM: physical key/pad/pedal/knob routing must keep the same sound. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <stdatomic.h>
#include <time.h>
#include <sched.h>
#define MUSICCOACH_DUAL_CORE 1
#define MUSICCOACH 1
static uint32_t worker_clock(void) {
    struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t);
    return (uint32_t)((uint64_t)t.tv_sec * 1000000u + t.tv_nsec / 1000u);
}
static void hold_worker(void);
#define AW_WORD _Atomic uint32_t
#define AW_LOAD(p) atomic_load_explicit(p, memory_order_acquire)
#define AW_STORE(p,v) atomic_store_explicit(p,v,memory_order_release)
#define AW_TICKS() worker_clock()
#define AW_TIMEOUT_TICKS 2000000u
#define AW_RAM_LOOP static
#define AW_IDLE() pthread_testcancel()
#define AW_HOLD() hold_worker()
#include "../firmware/src/audio_worker.h"
static void hold_worker(void) {
    while (AW_LOAD(&audio_worker.complete) != AW_LOAD(&audio_worker.request)) sched_yield();
}
static int serial_reference;
#define audio_worker_submit(fn,context) (serial_reference ? 0 : audio_worker_submit(fn,context))
#define __attribute__(x)
#define memset felucca_memset
#define memcpy felucca_memcpy
#define memcmp felucca_memcmp
#ifndef MUSICCOACH_TEST_ENGINE
#define MUSICCOACH_TEST_ENGINE "../web/audio/smk-engine.c"
#endif
#include MUSICCOACH_TEST_ENGINE
#undef memset
#undef memcpy
#undef memcmp
static void *worker(void *unused) { (void)unused; audio_worker_loop(); return 0; }
int main(int argc,char **argv){
 assert(argc==3);serial_reference=atoi(argv[1])==0;
 FILE *pcm=fopen(argv[2],"wb");assert(pcm);synth_init();mc.boot_muted=1;
 pthread_t thread;assert(!pthread_create(&thread,0,worker,0));
 while(!AW_LOAD(&audio_worker.ready))sched_yield();audio_worker_online=1;
 uint64_t energy=0;
 for(unsigned block=0;block<6000;block++){
  assert(AW_LOAD(&audio_worker.request)==AW_LOAD(&audio_worker.complete));
  audio_worker_check();
  if(block%1000==0){smk37_sustain(0);for(unsigned k=0;k<37;k++)smk37_play_key_event(k,0);mc.sound=block/1000;}
  if(block%160==10)for(unsigned k=4;k<30;k+=5)smk37_play_key_event(k,60+k);
  if(block%160==40)smk37_sustain(1);
  if(block%160==60)for(unsigned k=4;k<30;k+=5)smk37_play_key_event(k,0);
  if(block%160==100)smk37_sustain(0);
  int32_t *samples=synth_render();
  assert(AW_LOAD(&audio_worker.request)==AW_LOAD(&audio_worker.complete));
  assert(fwrite(samples,sizeof *samples,CTL*2,pcm)==CTL*2);
  for(unsigned i=0;i<CTL*2;i++)energy+=samples[i]<0?-(int64_t)samples[i]:samples[i];
 }
 assert(energy&&!audio_worker.timeouts&&!audio_worker.rejected);
 assert(serial_reference?!audio_worker.jobs:audio_worker.jobs>0);
 assert(!pthread_cancel(thread));assert(!pthread_join(thread,0));assert(!fclose(pcm));
 printf("MusicCoach %s: %u jobs, energy %llu\n",serial_reference?"serial":"concurrent",audio_worker.jobs,(unsigned long long)energy);return 0;
}
