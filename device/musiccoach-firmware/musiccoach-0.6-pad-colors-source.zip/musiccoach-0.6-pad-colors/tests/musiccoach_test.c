#include <assert.h>
#include <stdio.h>
#define MUSICCOACH_SMK 1
#include "../firmware/src/musiccoach.h"
static uint32_t now;
static void tick(unsigned ms){while(ms){unsigned d=ms>20?20:ms;now+=d;mc_advance(now);ms-=d;}}
static void setup(unsigned lesson,unsigned mode){now=0;mc_init(0);mc_qread=mc_qwrite=0;mc.lesson=lesson;mc.mode=mode;mc.countin=0;mc_command(MC_START,0);tick(1);}
int main(void){
 setup(0,MC_LEARN);tick(10000);assert(mc.index==0&&mc.beat==1000);
 mc_key(61,100,now);assert(mc.wrong==1&&mc.hits==0);mc_key(61,0,now);
 mc_key(60,100,now);assert(mc.hits==1&&mc.index==1);mc_key(60,100,now);assert(mc.hits==1);mc_key(60,0,now);
 for(unsigned i=1;i<mc_current()->count;i++){tick(2000);unsigned n=mc_current()->steps[i].note[0];mc_key(n,100,now);mc_key(n,0,now);}tick(2000);assert(mc.page==MC_RESULT&&mc_stars()==2);
 setup(2,MC_LEARN);tick(2000);mc_key(60,100,now);mc_key(64,100,now);assert(mc.hits==0);mc_key(67,100,now);assert(mc.hits==1);
 setup(5,MC_LEARN);tick(2000);mc_key(60,100,now);tick(2000);mc_key(60,100,now);assert(mc.hits==1);mc_key(60,0,now);mc_key(60,100,now);assert(mc.hits==2);
 setup(0,MC_RHYTHM);tick(20000);assert(mc.page==MC_RESULT&&mc.hits==0&&mc.misses==mc_current()->count&&mc_stars()==0);
 setup(0,MC_DEMO);tick(800);assert(mc_demo_mask()!=0);mc_key(60,100,now);assert(mc.hits==0);tick(20000);assert(mc.page==MC_RESULT&&mc_stars()==0);
 setup(0,MC_LEARN);mc_command(MC_BACK,0);tick(1);mc.countin=1;mc_command(MC_START,0);tick(1);assert(mc.beat<0);mc_key(60,100,now);assert(mc.hits==0);
 mc_command(MC_START,0);tick(1);int pos=mc.beat;tick(5000);assert(mc.beat==pos);
 mc_command(MC_TEMPO,5000);tick(1);assert(mc.bpm==160);mc_command(MC_TEMPO,-5000);tick(1);assert(mc.bpm==40);
 for(unsigned l=0;l<MC_LESSONS;l++)for(unsigned s=0;s<mc_lessons[l].count;s++)for(unsigned n=0;n<mc_lessons[l].steps[s].count;n++)assert(mc_lessons[l].kind==1?(mc_lessons[l].steps[s].note[n]>=36&&mc_lessons[l].steps[s].note[n]<=51):(mc_lessons[l].steps[s].note[n]>=53&&mc_lessons[l].steps[s].note[n]<=79));
 setup(0,MC_LEARN);tick(2000);mc_key(60,100,now);mc_key(60,0,now);
 mc_command(MC_SHUTTLE,2);tick(1);assert(mc.index==2&&mc.hits==0&&mc.running&&mc.seeked);
 mc_command(MC_START,0);tick(1);mc_command(MC_SHUTTLE,-100);tick(1);assert(mc.beat==0&&!mc.running&&mc.index==0);
 mc_command(MC_SHUTTLE,100);tick(1);assert(mc.beat==mc_at(mc_current()->count-1)&&mc.index==mc_current()->count-1);
 mc.hits=1;assert(mc_stars()==0);mc_command(MC_RESTART,0);tick(1);assert(!mc.seeked);
 mc_command(MC_SOUND,-1);tick(1);assert(mc.sound==MC_SOUNDS-1);mc_command(MC_SOUND,1);tick(1);assert(mc.sound==0);
 mc_command(MC_VOLUME,-100);tick(1);assert(mc.volume==0);mc_command(MC_VOLUME,100);tick(1);assert(mc.volume==64);
 /* Every playable study can complete; Demo and partial sequence never earn stars. */
 for(unsigned l=0;l<MC_LESSONS;l++){
  setup(l,MC_LEARN);
  if(mc_current()->kind==2){
   assert(mc.seq_on);mc_train_toggle(2);assert(mc.page!=MC_RESULT);mc_train_toggle(2);
   for(unsigned lane=0;lane<4;lane++){mc_apply(MC_TRAIN_LANE,(int)lane-mc.train_lane);for(unsigned pad=0;pad<16;pad++)if(mc_current()->target[lane]&(1u<<pad))mc_train_toggle(pad);}
   assert(mc.page==MC_RESULT&&mc.best[l]==3&&!mc.seq_on);continue;
  }
  for(unsigned step=0;step<mc_current()->count;step++){
   tick(2000);assert(mc.index==step);const mc_step *st=&mc_current()->steps[step];
   for(unsigned n=0;n<st->count;n++)mc_key(st->note[n],100,now);
   for(unsigned n=0;n<st->count;n++)mc_key(st->note[n],0,now);
   assert(mc.index==step+1);
  }
  tick(4000);assert(mc.page==MC_RESULT&&mc_stars()==3);
 }
 setup(47,MC_LEARN);tick(2000);mc_key(60,100,now);assert(!mc.hits&&!mc.wrong);mc_key(37,100,now);assert(mc.wrong==1);mc_key(36,100,now);assert(mc.hits==1);
 setup(MC_LESSONS-4,MC_DEMO);mc_train_toggle(0);assert(!mc.train_pattern[0]&&!mc_stars());
 mc_apply(MC_KEYBOARD,0);assert(mc.lesson==0&&!mc.seq_on);mc_apply(MC_LESSON,-1);assert(mc.lesson==46);
 for(unsigned theme=0;theme<12;theme++){mc.theme=theme;for(unsigned pad=0;pad<16;pad++){unsigned rgb=mc_pad_rgb(pad,now);assert((rgb>>16)<=8&&((rgb>>8)&255)<=8&&(rgb&255)<=8);}}
 puts("MusicCoach: lessons, timing, grading, shuttle boundaries, sound selection and volume pass");
}
